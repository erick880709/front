# SherLock — Frontend Angular ("Caribe"/BDS)

Scaffold real (no HTML estático) del frontend de SherLock (Bancolombia /
PersonalSoft), construido en Angular 22 sobre el workspace `frontend/sherlock-app/`.
Migra los conceptos de UI/UX ya validados por el prototipo interno del banco
(`context/codigo/Part2/web/new.html`, ver `EXPLICACION_CODIGO.md`) hacia
componentes Angular reales, siguiendo como fuente de verdad
`resources/ux/ui/documento-funcional-tecnico-pantallas.html` (12 pantallas) y
las historias de usuario en `resources/functional/hu/`.

## Cómo correrlo

```bash
npm install
npx ng build shell --configuration production      # build de producción del host
npx ng build dashboard --configuration production   # build de producción del remoto
npx ng serve dashboard --port 4201                   # en una terminal (remoto primero)
npx ng serve shell --port 4200                       # en otra terminal (host)
```

Con ambos `ng serve` corriendo, `http://localhost:4200` es la app completa: el
shell carga en runtime el remoto `dashboard` vía Module Federation.

## Estructura

```
frontend/sherlock-app/
  angular.json, package.json, tsconfig.json   -> workspace Angular CLI (sin Nx)
  projects/
    shell/            -> host: navegación (HU-10), layout, guard de Entra ID (stub),
                          features servidores/usuarios/grupos/rutas-ataque/magic-agent,
                          búsqueda global (HU-11)
    dashboard/         -> remoto Module Federation de referencia: indicador de riesgo
                          global (HU-07), gráfico de severidad (HU-08), estado de
                          fuentes de exposición
```

Dentro de `projects/shell/src/app/`:

```
core/
  models/       -> Servidor, Usuario, Grupo, Hallazgo, TécnicaMitre, RutaAtaque, etc.
                   (alineados con la sección 9 del Documento de Arquitectura, entidad
                   lógica IDENTIDAD_CORRELACIONADA)
  services/     -> clientes HTTP hacia el Monolito de Negocio (servidores, usuarios,
                   grupos, fuentes, magic-agent) y AuthService (stub Entra ID)
  guards/       -> authGuard (stub, preparado para TT-02)
  interceptors/ -> authInterceptor (stub, preparado para TT-02)
shared/
  empty-state/          -> HU-17, estado vacío estandarizado transversal
  severity-badge/       -> badge de severidad con los 4 colores reales de Caribe/BDS
  identity-filter-bar/  -> HU-11/HU-12, búsqueda + filtros combinables
  mitre-panel/          -> panel colapsable de técnicas MITRE + evidencia
  paginator/             -> paginador prev/next (patrón real Molecules/Paginator)
layout/
  shell-layout/          -> header + navegación (HU-10) + <router-outlet>
features/
  servidores/            -> listado (HU-11/HU-12) + detalle (HU-13)
  usuarios/               -> listado + detalle (HU-14)
  grupos/                 -> listado + detalle (HU-15)
  rutas-ataque/            -> AttackPathTab, componente compartido en modo vacío (HU-16)
  magic-agent/             -> chat UI mínimo (HU-23)
  busqueda/                -> resultados de búsqueda global (HU-11)
```

## Decisiones de Module Federation

- **Mecanismo elegido: `@angular-architects/native-federation` (v22.1.3), no
  `@angular-architects/module-federation` (el paquete webpack "clásico").**
  Angular 22 usa por defecto el builder esbuild (`@angular/build:application`);
  el paquete webpack clásico requiere volver a un builder `custom-webpack`
  incompatible con ese default. `native-federation` es la evolución pensada
  específicamente para el builder esbuild/Vite de Angular: usa import maps
  ESM nativos del navegador en vez de un runtime de Module Federation de
  webpack. No existe (a la fecha, Angular 22.1) una solución de Module
  Federation "nativa" del framework en sí — `native-federation` es hoy el
  estándar de facto del ecosistema para esta versión, y es la que Angular CLI
  instala vía `ng add`.
- **Shell (`shell`) como host, `dashboard` como único remoto de referencia**,
  tal como pide TT-13 ("al menos un remoto"). El resto de módulos
  (servidores/usuarios/grupos/rutas-ataque/magic-agent) vive dentro del
  propio proyecto `shell` este ciclo — TT-13/ADR-008 no exigen que cada
  módulo de negocio sea su propio remoto, solo que la arquitectura quede
  demostrablemente preparada para eso.
- **El shell carga el remoto en runtime incluso en este ciclo de bundle
  único**: la ruta `/dashboard` usa `loadRemoteModule('dashboard',
  './Component')` contra `http://localhost:4201/remoteEntry.json` (puerto
  configurado en `angular.json`), no un import estático. Esto es justamente
  lo que ADR-008 pide dejar operativo, aunque el despliegue real de este
  ciclo empaquete host y remoto juntos (mismo pipeline CI/CD, mismo bucket
  S3/CloudFront).
- **`shareAll` con `singleton: true` para todas las dependencias**, y
  `includeSecondaries: { keepAll: true }` forzado para `@angular/core`
  (configuración generada por el propio schematic de `native-federation`,
  no modificada) — evita instancias duplicadas de Angular/Router/RxJS entre
  host y remoto. Esto es lo que permite que `dashboard` inyecte el mismo
  `Router` del shell y navegue (`/servidores?severidad=...`, HU-08 CA2) sin
  necesitar su propio outlet ni su propia instancia de enrutador.
- **Contratos de tipos duplicados entre `shell` y `dashboard`** (ver
  `projects/dashboard/src/app/core/dashboard.model.ts`), en vez de que
  `dashboard` importe desde `projects/shell/...`. Es intencional: cada
  remoto de Module Federation debe poder compilarse y desplegarse de forma
  independiente (ese es el punto de tener más de un `project` en el
  workspace). Si en el futuro se agregan más remotos, la extracción de estos
  contratos a una librería Angular compartida (o un paquete de tipos interno)
  sería el siguiente paso — no se resolvió aquí porque con un solo remoto de
  referencia sería sobre-ingeniería.
- **Riesgo heredado y ya documentado en el Documento de Arquitectura**
  (sección 13): Module Federation introduce complejidad de configuración sin
  un requerimiento de negocio actual que lo justifique. Este scaffold no
  resuelve esa discusión — solo la deja operativa y documentada, tal como
  pide ADR-008, para que el banco decida si la mantiene o la simplifica a una
  SPA monolítica sin MF.

## Decisiones de librerías

- **Chart.js (`chart.js` npm, v4.5.1)** para el gráfico de distribución de
  severidad (HU-08). Es la misma librería que ya validó el prototipo interno
  del banco (`EXPLICACION_CODIGO.md` §4/§6). Se evaluó primero si el sistema
  de diseño Caribe/BDS trae un componente de gráficos nativo: el catálogo
  real de 71 componentes auditado en
  `resources/ux/ui/figma/README-importar-a-figma.md` no incluye ningún
  organismo de tipo "Chart" — Chart.js es la única opción con un caso de uso
  real este ciclo, no una preferencia arbitraria.
- **Cytoscape.js + Dagre NO se agregó como dependencia todavía.** Aunque el
  prototipo ya la validó para el grafo de rutas de ataque y es la candidata
  natural para cuando ACL esté disponible (ver ADR-005, HU-16), este ciclo
  la pestaña "Attack Paths" opera en modo vacío — agregar la librería sin un
  dato real que graficar sería la dependencia sin uso real que el alcance de
  este scaffold prohíbe explícitamente. `AttackPathTab`
  (`features/rutas-ataque/attack-path-tab.ts`) ya deja el contrato de datos
  (`RutaAtaque`) listo para cuando se decida activarla.
- **Standalone Components + Signals** en todo el scaffold (ni un solo
  `NgModule`), consistente con que Angular 22 ya trae standalone como el
  modo por defecto de `ng generate` y con que `native-federation` no exige
  NgModules para nada de lo construido aquí.
- **Sin librería de estado global (NgRx/Akita/etc.)**: el estado de cada
  vista es local (signals + `toSignal` sobre streams HTTP atados a los
  `queryParams`/`params` de la ruta). Con el alcance actual (listados +
  detalle + un chat simple) no hay justificación para una librería de estado
  adicional.

## Qué NO se construyó (y por qué)

- **Autenticación real (Entra ID/OIDC).** `AuthService`
  (`core/services/auth.service.ts`), `authGuard`
  (`core/guards/auth.guard.ts`) y `authInterceptor`
  (`core/interceptors/auth.interceptor.ts`) son stubs explícitos: no hay JWT
  propio, no hay secreto hardcodeado, no hay contraseña, no se guarda ningún
  token en `localStorage`. Son los puntos de extensión exactos que TT-02
  reemplazará por `@azure/msal-angular` (Authorization Code Flow + PKCE,
  según `Documento_Arquitectura_SherLock.md` §10). Se documenta así, con
  comentarios inline en cada archivo, precisamente para no repetir los
  antipatrones del prototipo (`auth.py`/`login.html`, ver
  `EXPLICACION_CODIGO.md` §5).
- **Recalculo de score/severidad en el cliente.** Ningún componente
  recalcula nada: `valorScore` y `severidad` se muestran tal cual los
  devuelve el Monolito de Negocio. Es la corrección deliberada del bug ya
  señalado en el prototipo (`EXPLICACION_CODIGO.md` §4/§5).
- **Integración real del grafo de rutas de ataque.** Ver sección anterior
  (Cytoscape.js no agregada todavía).
- **Backend real / mocks de datos.** Los servicios (`ServidoresService`,
  `UsuariosService`, `GruposService`, `FuentesService`, `MagicAgentService`,
  `DashboardApiService`) llaman a los endpoints documentados en
  `documento-funcional-tecnico-pantallas.html` bajo `environment.apiBaseUrl`
  (`/api`, relativo — CloudFront enruta al API Gateway del Monolito de
  Negocio). Sin ese backend desplegado, los listados y detalles muestran el
  estado de carga y, ante cualquier error HTTP, el estado vacío estandarizado
  (nunca una pantalla rota) — no se agregó un servidor de mocks porque no fue
  pedido y habría sido otro artefacto a mantener sin valor real para el
  scaffold.
- **`groups.xlsx`/expansión de grupos anidados, IOE/Spider/Carpetas reales,
  etc.** — cualquier hallazgo de una fuente no habilitada este ciclo se
  resuelve en el frontend con `EmptyState` (HU-17), nunca simulando datos.

## Qué falta para conectar con el backend real

1. **Entra ID real**: reemplazar `AuthService`/`authGuard`/`authInterceptor`
   por la integración MSAL cuando TT-02 esté lista; el contrato público de
   los tres ya está pensado para no romper `ShellLayout` ni las rutas.
2. **Contrato de API definitivo**: los endpoints usados (`/api/servers`,
   `/api/users`, `/api/groups`, sub-recursos por fuente, `/api/chat`,
   `/api/sources/status`, `/api/sources/reload`) son la propuesta documentada
   en `documento-funcional-tecnico-pantallas.html`, marcada ahí mismo como
   "pendiente de validación formal con el equipo de backend" — hay que
   confirmar nombres, paginación y forma exacta de respuesta antes de
   considerarlos definitivos.
3. **Despliegue real (CloudFront + S3)**: el criterio de Done de TT-13 pide
   que el proyecto "compile y despliegue vía CloudFront + S3" — este
   scaffold ya compila (`ng build shell`/`ng build dashboard` en
   producción, ambos verificados), pero no se configuró pipeline de
   despliegue (fuera del alcance de un scaffold de frontend).
4. **Activar Attack Paths con datos reales** cuando ACL esté disponible
   (ver ADR-005): reemplazar el contenido de `AttackPathTab` por el grafo
   real (Cytoscape.js + Dagre) sin cambiar el contrato `RutaAtaque` ya
   definido.
