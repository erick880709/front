/**
 * Configuración de entorno (desarrollo). `apiBaseUrl` apunta al Monolito de
 * Negocio (nunca al Monolito de Ingesta, ver Documento_Arquitectura_SherLock.md
 * §6). En despliegue real, CloudFront enruta `/api/*` al API Gateway privado
 * que expone el Monolito de Negocio (ver arquitectura, sección 12) — por eso
 * basta una ruta relativa, sin host, ni en dev ni en prod.
 *
 * `entraId` queda como configuración reservada para cuando TT-02 conecte el
 * flujo real de Entra ID/OIDC (Authorization Code Flow + PKCE, ver sección 10
 * del documento de arquitectura). Hoy no se usa: el AuthService actúa como
 * stub (ver core/services/auth.service.ts).
 */
export const environment = {
  production: false,
  apiBaseUrl: '/api',
  entraId: {
    tenantId: '',
    clientId: '',
    redirectUri: '',
  },
};
