export const environment = {
  production: true,
  apiBaseUrl: '/api',
  entraId: {
    tenantId: '',
    clientId: '',
    redirectUri: '',
  },
};
