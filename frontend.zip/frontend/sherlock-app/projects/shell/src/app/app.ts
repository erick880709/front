import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * Componente raíz del host. El layout real (header, navegación HU-10) vive
 * en `ShellLayout` y se monta vía routing (ver app.routes.ts) para poder
 * protegerlo con `authGuard` como cualquier otra ruta del shell.
 */
@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  template: `<router-outlet />`,
})
export class App {}
