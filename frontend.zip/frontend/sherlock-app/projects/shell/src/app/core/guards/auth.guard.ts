import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard funcional preparado para Entra ID (TT-02). Hoy delega en el stub de
 * `AuthService`, que siempre reporta autenticado — no hay validación de
 * `nbf`/`exp`/`aud`/firma en el cliente (esa validación, cuando exista,
 * ocurre igualmente en el backend vía el filtro OIDC del Monolito de
 * Negocio; el guard de frontend solo evita el parpadeo de UI protegida,
 * nunca es la barrera de seguridad real — RT-028: "toda validación de
 * autenticación/autorización ocurre en el backend, nunca en el cliente").
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.estaAutenticado()) {
    return true;
  }

  auth.iniciarSesion();
  return router.createUrlTree(['/']);
};
