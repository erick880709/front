import { Injectable, signal } from '@angular/core';

/**
 * Stub de autenticación preparado para Entra ID / OIDC (TT-02).
 *
 * Qué NO hace deliberadamente, por instrucción explícita del alcance de TT-13:
 * - No implementa JWT propio (sin `SECRET_KEY` hardcodeado, sin SHA-256 sin
 *   sal) — ese es exactamente el antipatrón documentado en
 *   `context/codigo/EXPLICACION_CODIGO.md` §5 (`auth.py` del prototipo).
 * - No guarda ningún token en `localStorage`. El único estado que mantiene
 *   es en memoria (una señal), y se pierde al recargar — es intencional: la
 *   integración real de Entra ID (Authorization Code Flow + PKCE, ver
 *   `Documento_Arquitectura_SherLock.md` §10) definirá dónde y cómo se
 *   conserva la sesión (lo más probable, vía la librería MSAL y su propio
 *   cache in-memory/sessionStorage con las protecciones que esa librería ya
 *   provee), no antes.
 *
 * Cuando TT-02 conecte Entra ID real, este servicio se reemplaza por (o
 * delega en) `@azure/msal-angular`, sin cambiar el contrato público
 * (`estaAutenticado`, `usuarioActual`, `iniciarSesion`, `cerrarSesion`) que ya
 * consumen el guard, el interceptor y el layout del shell.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  /** Mientras no exista integración real, el guard deja pasar siempre
   * (ver core/guards/auth.guard.ts) y este flag queda en `true` para que el
   * resto de la UI (avatar, nombre de analista) tenga un valor de referencia
   * en desarrollo. No es una sesión real ni debe tratarse como tal. */
  private readonly _estaAutenticado = signal(true);
  private readonly _usuarioActual = signal<{ nombre: string; correo: string } | null>({
    nombre: 'Analista de Brechas (stub)',
    correo: 'pendiente-entra-id@bancolombia.com.co',
  });

  readonly estaAutenticado = this._estaAutenticado.asReadonly();
  readonly usuarioActual = this._usuarioActual.asReadonly();

  /** Punto de extensión: TT-02 reemplaza este método por
   * `msalService.loginRedirect()` / `loginPopup()`. */
  iniciarSesion(): void {
    this._estaAutenticado.set(true);
  }

  /** Punto de extensión: TT-02 reemplaza este método por
   * `msalService.logoutRedirect()`. */
  cerrarSesion(): void {
    this._estaAutenticado.set(false);
    this._usuarioActual.set(null);
  }
}
