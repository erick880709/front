import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FiltrosIdentidad, Hallazgo, RespuestaPaginada, RutaAtaque, TecnicaMitreDetectada } from '../models/comun.model';
import { ServidorDetalle, ServidorResumen } from '../models/servidor.model';

/**
 * Cliente HTTP del módulo Servidores del Monolito de Negocio. Endpoints según
 * `resources/ux/ui/documento-funcional-tecnico-pantallas.html` (pantallas
 * 01-07) — contrato propuesto, pendiente de validación formal con el equipo
 * de backend antes de considerarse definitivo.
 */
@Injectable({ providedIn: 'root' })
export class ServidoresService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiBaseUrl}/servers`;

  listar(filtros: FiltrosIdentidad): Observable<RespuestaPaginada<ServidorResumen>> {
    return this.http.get<RespuestaPaginada<ServidorResumen>>(this.base, {
      params: this.aParams(filtros),
    });
  }

  obtenerDetalle(identidadId: string): Observable<ServidorDetalle> {
    return this.http.get<ServidorDetalle>(`${this.base}/${identidadId}`);
  }

  obtenerCarpetas(identidadId: string): Observable<Hallazgo[]> {
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/carpetas`);
  }

  obtenerAdmins(identidadId: string, anomalia?: string): Observable<Hallazgo[]> {
    let params = new HttpParams();
    if (anomalia) {
      params = params.set('anomalia', anomalia);
    }
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/admins`, { params });
  }

  obtenerVirtualPatching(identidadId: string): Observable<Hallazgo[]> {
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/virtual-patching`);
  }

  obtenerIoe(identidadId: string): Observable<Hallazgo[]> {
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/ioe`);
  }

  obtenerSpider(identidadId: string): Observable<Hallazgo[]> {
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/spider`);
  }

  obtenerMitre(identidadId: string): Observable<TecnicaMitreDetectada[]> {
    return this.http.get<TecnicaMitreDetectada[]>(`${this.base}/${identidadId}/mitre`);
  }

  /** HU-16: contrato reservado, sin datos reales este ciclo (ADR-005). */
  obtenerRutasAtaque(identidadId: string): Observable<RutaAtaque[]> {
    return this.http.get<RutaAtaque[]>(`${this.base}/${identidadId}/attack-paths`);
  }

  exportar(formato: 'json' | 'csv' | 'pdf', filtros: FiltrosIdentidad): Observable<Blob> {
    return this.http.post(`${this.base}/export`, filtros, {
      params: new HttpParams().set('formato', formato),
      responseType: 'blob',
    });
  }

  private aParams(filtros: FiltrosIdentidad): HttpParams {
    let params = new HttpParams();
    if (filtros.q) params = params.set('search', filtros.q);
    if (filtros.severidad) params = params.set('severidad', filtros.severidad);
    if (filtros.tipoRiesgo) params = params.set('tipoRiesgo', filtros.tipoRiesgo);
    params = params.set('page', String(filtros.page ?? 0));
    params = params.set('size', String(filtros.size ?? 10));
    return params;
  }
}
