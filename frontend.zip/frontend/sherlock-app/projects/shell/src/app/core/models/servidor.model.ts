import { Hallazgo, Severidad, TecnicaMitreDetectada } from './comun.model';

/** Tarjeta de servidor en el listado (pantalla 02). */
export interface ServidorResumen {
  identidadId: string;
  ip: string;
  hostname?: string;
  severidad: Severidad;
  valorScore: number;
  conteoCarpetas?: number;
  conteoAdmins?: number;
  conteoAttackPaths?: number;
  conteoIoe?: number;
  conteoGrupos?: number;
  conteoAlertas?: number;
}

/** Detalle completo de servidor (pantallas 03-07, HU-13).
 * `carpetas`, `admins`, `spider` e `ioe` pueden llegar vacíos este ciclo según
 * la fuente disponible — el componente de detalle debe mostrar el estado
 * vacío estandarizado (HU-17) para cada uno, nunca un error. */
export interface ServidorDetalle {
  identidadId: string;
  ip: string;
  hostname?: string;
  sistemaOperativo?: string;
  owner?: string;
  severidad: Severidad;
  valorScore: number;
  attackScenario?: string;
  formulaVersion?: string;
  fechaUltimaCorrelacion?: string;
  tecnicasMitre: TecnicaMitreDetectada[];
  hallazgosTenable: Hallazgo[];
  hallazgosVirtualPatching: Hallazgo[];
  carpetas: Hallazgo[];
  admins: Hallazgo[];
  ioe: Hallazgo[];
  spider: Hallazgo[];
}
