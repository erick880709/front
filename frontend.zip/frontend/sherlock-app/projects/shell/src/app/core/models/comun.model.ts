/**
 * Modelos transversales del dominio SherLock, alineados con la entidad lógica
 * IDENTIDAD_CORRELACIONADA y sus relaciones descritas en la sección 9 (Modelo
 * de Datos) de `resources/architecture/Documento_Arquitectura_SherLock.md`.
 *
 * IMPORTANTE: el frontend NUNCA recalcula `score` ni `severidad`. Ambos
 * valores se muestran tal cual los devuelve el Monolito de Negocio. El
 * prototipo Python (`context/codigo/Part2/web/new.html`) sí los recalculaba
 * en el cliente y el propio análisis del prototipo (`EXPLICACION_CODIGO.md`
 * §4, §5) lo señala como una inconsistencia — no se repite ese patrón aquí.
 */

/** Cuatro niveles de severidad reales del sistema de diseño Caribe/BDS
 * (`.bc-badge-red|orange|yellow|green`, ver figma/README-importar-a-figma.md). */
export type Severidad = 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA';

/** Tipo de riesgo / fuente de exposición (para el filtro combinable de HU-12). */
export type TipoRiesgo =
  | 'CARPETAS'
  | 'ADMINS'
  | 'ATTACK_PATHS'
  | 'VIRTUAL_PATCHING'
  | 'IOE'
  | 'SPIDER';

/** Técnica MITRE ATT&CK detectada para una identidad (servidor/usuario/grupo),
 * con la evidencia que la disparó (RF-018, pantalla 07). */
export interface TecnicaMitreDetectada {
  tecnicaId: string;
  nombreTecnica: string;
  evidencia: string;
  fechaDeteccion: string;
}

/** Hallazgo genérico de una fuente (Tenable IE/VP/Carpetas/Admins/Spider/IOE).
 * El campo `fuente` determina en qué sub-pestaña se agrupa (HU-13 CA2). */
export interface Hallazgo {
  hallazgoId: string;
  fuente: TipoRiesgo | 'TENABLE_IE' | 'VIRTUAL_PATCHING';
  titulo: string;
  detalle: string;
  severidad: Severidad;
  recomendacion?: string;
}

/** Respuesta paginada estándar de los listados (`/api/servers`, `/api/users`,
 * `/api/groups`), según lo documentado en documento-funcional-tecnico-pantallas.html. */
export interface RespuestaPaginada<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}

/** Filtros combinables de severidad/tipo de riesgo + búsqueda de texto libre
 * (HU-11, HU-12). Se serializan tal cual en los query params de la URL. */
export interface FiltrosIdentidad {
  q?: string;
  severidad?: Severidad;
  tipoRiesgo?: TipoRiesgo;
  page?: number;
  size?: number;
}

/** Estado de una fuente de exposición (panel "Fuentes de Exposición" del
 * dashboard, entidad lógica ESTADO_FUENTE). */
export interface EstadoFuente {
  fuenteId: string;
  nombre: string;
  ultimaSincronizacion: string | null;
  estado: 'OK' | 'DESACTUALIZADA' | 'SIN_DATOS' | 'ERROR';
}

/** Ruta de ataque — contrato reservado, sin datos reales este ciclo
 * (ADR-005, HU-16, entidad lógica RUTA_ATAQUE). El campo `estado` es el único
 * garantizado hoy: siempre `SIN_DATOS` hasta que ACL esté disponible. */
export interface RutaAtaque {
  identidadOrigenId: string;
  identidadDestinoId: string;
  tipoPermiso?: string;
  estado: 'SIN_DATOS' | 'DISPONIBLE';
}

/** Tipo de identidad correlacionada — determina qué módulo/rutas aplican. */
export type TipoIdentidad = 'SERVIDOR' | 'USUARIO' | 'GRUPO';
