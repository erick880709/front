import { EstadoFuente, Severidad } from './comun.model';

/** Respuesta de `GET /api/servers/dashboard-summary` (pantalla 01, HU-07/HU-08). */
export interface DashboardResumen {
  /** Porcentaje 0-100 ya calculado por el backend — nunca se recalcula aquí. */
  riesgoGlobalPorcentaje: number;
  nivelRiesgoGlobal: string; // ej. "HIGH RISK"
  distribucionSeveridad: Record<Severidad, number>;
  exposicionPorBrecha: Record<string, number>;
  tecnicasMitreFrecuentes: { tecnicaId: string; nombreTecnica: string; conteo: number }[];
}

export interface FuentesEstadoResumen {
  fuentes: EstadoFuente[];
}
