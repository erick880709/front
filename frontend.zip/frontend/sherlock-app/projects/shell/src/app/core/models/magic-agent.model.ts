/** Modelo del chat del Sherlock Magic Agent (HU-23, prioridad Baja, alcance
 * mínimo). El matching de intención y el motor de reglas viven en el
 * Monolito de Negocio (RF-014 a RF-017) — el frontend solo envía el texto
 * libre y renderiza la respuesta ya resuelta, sin lógica de negocio propia. */
export type MagicAgentEmisor = 'USUARIO' | 'AGENTE';

export interface MagicAgentMensaje {
  id: string;
  emisor: MagicAgentEmisor;
  texto: string;
  fecha: Date;
  tarjeta?: MagicAgentTarjetaRespuesta;
  /** true si el backend no pudo resolver la identidad consultada (HU-23 CA3):
   * se notifica en la UI en vez de fallar silenciosamente. */
  noResuelto?: boolean;
}

/** Tarjeta de respuesta estructurada (resumen, ruta de exposición, MITRE,
 * evidencia) devuelta por `POST /api/chat`. */
export interface MagicAgentTarjetaRespuesta {
  resumen: string;
  tecnicasMitre?: string[];
  evidencia?: string[];
}
