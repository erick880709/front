import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { DashboardResumen, FuentesEstadoResumen } from '../models/dashboard.model';

/** Cliente HTTP del dashboard agregado (pantalla 01, HU-07/HU-08) y del panel
 * de estado de fuentes de exposición. Consumido hoy por el remoto Angular
 * `dashboard` (Module Federation, ver TT-13/ADR-008) — se declara también en
 * el shell por si una vista del shell necesita el mismo dato sin pasar por
 * el remoto (ej. breadcrumbs de estado de fuentes). */
@Injectable({ providedIn: 'root' })
export class FuentesService {
  private readonly http = inject(HttpClient);

  obtenerResumenDashboard(): Observable<DashboardResumen> {
    return this.http.get<DashboardResumen>(`${environment.apiBaseUrl}/servers/dashboard-summary`);
  }

  obtenerEstadoFuentes(): Observable<FuentesEstadoResumen> {
    return this.http.get<FuentesEstadoResumen>(`${environment.apiBaseUrl}/sources/status`);
  }

  recargarFuentes(): Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/sources/reload`, {});
  }
}
