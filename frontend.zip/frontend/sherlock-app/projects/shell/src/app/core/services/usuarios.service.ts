import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FiltrosIdentidad, Hallazgo, RespuestaPaginada, RutaAtaque, TecnicaMitreDetectada } from '../models/comun.model';
import { GrupoAsociado, ServidorRelacionado, UsuarioDetalle, UsuarioResumen } from '../models/usuario.model';

/** Cliente HTTP del módulo Usuarios del Monolito de Negocio (pantallas 08-09). */
@Injectable({ providedIn: 'root' })
export class UsuariosService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiBaseUrl}/users`;

  listar(filtros: FiltrosIdentidad): Observable<RespuestaPaginada<UsuarioResumen>> {
    let params = new HttpParams();
    if (filtros.q) params = params.set('search', filtros.q);
    if (filtros.severidad) params = params.set('severidad', filtros.severidad);
    if (filtros.tipoRiesgo) params = params.set('tipoRiesgo', filtros.tipoRiesgo);
    params = params.set('page', String(filtros.page ?? 0));
    params = params.set('size', String(filtros.size ?? 10));
    return this.http.get<RespuestaPaginada<UsuarioResumen>>(this.base, { params });
  }

  obtenerDetalle(identidadId: string): Observable<UsuarioDetalle> {
    return this.http.get<UsuarioDetalle>(`${this.base}/${identidadId}`);
  }

  obtenerServersAdmin(identidadId: string): Observable<ServidorRelacionado[]> {
    return this.http.get<ServidorRelacionado[]>(`${this.base}/${identidadId}/servers-admin`);
  }

  obtenerServersControl(identidadId: string): Observable<ServidorRelacionado[]> {
    return this.http.get<ServidorRelacionado[]>(`${this.base}/${identidadId}/servers-control`);
  }

  obtenerGrupos(identidadId: string): Observable<GrupoAsociado[]> {
    return this.http.get<GrupoAsociado[]>(`${this.base}/${identidadId}/groups`);
  }

  obtenerIoe(identidadId: string): Observable<Hallazgo[]> {
    return this.http.get<Hallazgo[]>(`${this.base}/${identidadId}/ioe`);
  }

  obtenerMitre(identidadId: string): Observable<TecnicaMitreDetectada[]> {
    return this.http.get<TecnicaMitreDetectada[]>(`${this.base}/${identidadId}/mitre`);
  }

  /** Tab "Grafo (ACL→Host)" (pantalla 09). Mismo contrato reservado
   * `RutaAtaque` que servidores/grupos — sin datos reales este ciclo (HU-16,
   * ADR-005). */
  obtenerGrafo(identidadId: string): Observable<RutaAtaque[]> {
    return this.http.get<RutaAtaque[]>(`${this.base}/${identidadId}/graph`);
  }
}
