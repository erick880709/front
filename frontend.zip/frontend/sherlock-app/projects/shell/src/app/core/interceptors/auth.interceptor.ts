import { HttpInterceptorFn } from '@angular/common/http';

/**
 * Interceptor de autenticación — punto de extensión para TT-02.
 *
 * Hoy es un paso vacío deliberado: no hay ningún token que adjuntar porque
 * `AuthService` es un stub sin sesión real (ver core/services/auth.service.ts).
 * Cuando Entra ID esté integrado, este interceptor adjuntará el header
 * `Authorization: Bearer <access_token>` obtenido de MSAL (nunca leído de
 * `localStorage` en texto plano, a diferencia de `apiFetch()` en el
 * prototipo — ver `EXPLICACION_CODIGO.md` §5, hallazgo 5).
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req);
};
