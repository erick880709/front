import { Hallazgo, Severidad, TecnicaMitreDetectada } from './comun.model';

export type TipoCuenta = 'SERVICIO' | 'NOMINAL' | 'DOMINIO';

/** Tarjeta de usuario en el listado (pantalla 08). */
export interface UsuarioResumen {
  identidadId: string;
  nombre: string;
  tipoCuenta: TipoCuenta;
  severidad: Severidad;
  valorScore: number;
  conteoAdmin?: number;
  conteoControl?: number;
  conteoGrupos?: number;
  conteoIoe?: number;
}

/** Grupo al que pertenece el usuario (tab "Groups", pantalla 09). */
export interface GrupoAsociado {
  identidadId: string;
  nombre: string;
}

/** Host donde el usuario es administrador local / tiene control ACL. */
export interface ServidorRelacionado {
  identidadId: string;
  hostname?: string;
  ip: string;
}

/** Detalle completo de usuario (pantalla 09, HU-14). */
export interface UsuarioDetalle {
  identidadId: string;
  nombre: string;
  dominio?: string;
  tipoCuenta: TipoCuenta;
  severidad: Severidad;
  valorScore: number;
  tecnicasMitre: TecnicaMitreDetectada[];
  ioe: Hallazgo[];
  serversAdmin: ServidorRelacionado[];
  serversControl: ServidorRelacionado[];
  /** Puede llegar vacío si la fuente de membresías de AD no está habilitada
   * este ciclo (HU-14 CA2: "si el dato está disponible en las fuentes
   * habilitadas") — se muestra estado vacío, no error. */
  grupos: GrupoAsociado[];
}
