import { Hallazgo, Severidad, TecnicaMitreDetectada } from './comun.model';
import { ServidorRelacionado } from './usuario.model';

export type TipoGrupo = 'SEGURIDAD' | 'DOMINIO';

/** Tarjeta de grupo en el listado (pantalla 10). */
export interface GrupoResumen {
  identidadId: string;
  nombre: string;
  tipoGrupo: TipoGrupo;
  severidad: Severidad;
  valorScore: number;
  conteoMiembros?: number;
  conteoAdmin?: number;
  conteoControl?: number;
  conteoIoe?: number;
}

/** Miembro del grupo (tab "Members", pantalla 11). */
export interface MiembroGrupo {
  identidadId: string;
  nombre: string;
  tipo: 'USUARIO' | 'GRUPO';
}

/** Detalle completo de grupo (pantalla 11, HU-15).
 * CA2 de HU-15 deja explícito que el origen del listado de miembros
 * (Tenable vs AD) está pendiente de definir con negocio — el contrato ya
 * queda preparado con este modelo para no romper el consumo cuando se
 * confirme la fuente. */
export interface GrupoDetalle {
  identidadId: string;
  nombre: string;
  tipoGrupo: TipoGrupo;
  severidad: Severidad;
  valorScore: number;
  tecnicasMitre: TecnicaMitreDetectada[];
  ioe: Hallazgo[];
  miembros: MiembroGrupo[];
  serversAdmin: ServidorRelacionado[];
  serversControl: ServidorRelacionado[];
}
