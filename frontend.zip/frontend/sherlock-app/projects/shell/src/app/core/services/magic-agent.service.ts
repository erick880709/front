import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { MagicAgentTarjetaRespuesta } from '../models/magic-agent.model';

interface RespuestaChatBackend {
  resumen: string;
  tecnicasMitre?: string[];
  evidencia?: string[];
  identidadResuelta: boolean;
}

/**
 * Cliente HTTP del Sherlock Magic Agent (HU-23). Sin lógica de matching de
 * intención ni de entidades en el frontend — eso vive por completo en el
 * Monolito de Negocio (motor de reglas rule-based, RF-014 a RF-017). Este
 * servicio solo envía el texto libre y devuelve la respuesta ya resuelta.
 */
@Injectable({ providedIn: 'root' })
export class MagicAgentService {
  private readonly http = inject(HttpClient);

  consultar(pregunta: string): Observable<RespuestaChatBackend> {
    return this.http.post<RespuestaChatBackend>(`${environment.apiBaseUrl}/chat`, { pregunta });
  }
}

export type { RespuestaChatBackend };
export type { MagicAgentTarjetaRespuesta };
