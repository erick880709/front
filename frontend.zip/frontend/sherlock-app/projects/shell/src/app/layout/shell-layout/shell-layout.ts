import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

/**
 * Layout raíz del shell: navegación entre módulos (HU-10) siempre visible en
 * el encabezado, con el módulo activo resaltado vía `routerLinkActive`
 * (HU-10 CA1/CA2), y acceso directo a la búsqueda global (HU-11).
 *
 * Este componente satisface también parte de TT-13 ("layout de dashboard...
 * montado sobre el scaffold"): el `<router-outlet>` es donde cuelgan tanto
 * las features locales del shell (servidores/usuarios/grupos) como la ruta
 * `/dashboard`, que carga en runtime el remoto Module Federation `dashboard`.
 */
@Component({
  selector: 'app-shell-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="sk-header">
      <div class="sk-header__brand">
        <span class="sk-header__wordmark" aria-hidden="true">Bancolombia</span>
        <span class="sk-header__nombre">SherLock</span>
        <span class="sk-header__institucional">
          Bancolombia S.A. · Centro de Excelencia de Ciberseguridad
        </span>
      </div>

      <nav class="sk-header__nav" aria-label="Navegación entre módulos">
        <a routerLink="/dashboard" routerLinkActive="sk-header__tab--activo" class="sk-header__tab">Dashboard</a>
        <a routerLink="/servidores" routerLinkActive="sk-header__tab--activo" class="sk-header__tab">Servers</a>
        <a routerLink="/usuarios" routerLinkActive="sk-header__tab--activo" class="sk-header__tab">Users</a>
        <a routerLink="/grupos" routerLinkActive="sk-header__tab--activo" class="sk-header__tab">Groups</a>
      </nav>

      <form class="sk-header__busqueda" (submit)="buscar($event)">
        <input
          name="q"
          type="search"
          placeholder="Buscar identidad por nombre, IP u owner..."
          aria-label="Búsqueda global de identidades"
        />
      </form>

      <span class="sk-header__actualizacion">
        Última actualización: {{ ultimaActualizacion }}
      </span>

      <div class="sk-header__usuario" [title]="auth.usuarioActual()?.correo ?? ''">
        <span class="sk-header__avatar" aria-hidden="true">{{ inicial() }}</span>
      </div>
    </header>

    <main class="sk-main">
      <router-outlet />
    </main>
  `,
  styles: `
    .sk-header {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 10px 24px;
      background: var(--sk-color-surface);
      border-bottom: 1px solid var(--sk-color-border);
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .sk-header__brand { display: flex; align-items: baseline; gap: 8px; font-weight: 700; flex-wrap: wrap; }
    .sk-header__wordmark {
      font-size: 1.1rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      color: var(--sk-color-brand-black);
      border-bottom: 3px solid var(--sk-color-primary);
      line-height: 1.1;
    }
    .sk-header__institucional {
      flex-basis: 100%;
      font-weight: 400;
      font-size: 0.7rem;
      color: var(--sk-color-text-muted);
    }
    .sk-header__actualizacion {
      font-size: 0.7rem;
      color: var(--sk-color-text-muted);
      white-space: nowrap;
    }
    .sk-header__nav { display: flex; gap: 4px; }
    .sk-header__tab {
      padding: 10px 14px;
      text-decoration: none;
      color: var(--sk-color-text-muted);
      font-weight: 600;
      font-size: 0.85rem;
      border-bottom: 3px solid transparent;
    }
    .sk-header__tab--activo {
      color: var(--sk-color-brand-black);
      border-bottom-color: var(--sk-color-brand-black);
    }
    .sk-header__busqueda { flex: 1; max-width: 360px; }
    .sk-header__busqueda input {
      width: 100%;
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.85rem;
    }
    .sk-header__avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--sk-color-info);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 0.8rem;
    }
    .sk-main { padding: 24px; max-width: 1280px; margin: 0 auto; }
  `,
})
export class ShellLayout {
  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  /** Fecha/hora de carga del shell en el navegador del cliente. No existe hoy
   * un campo del backend para "última actualización" a nivel global de la
   * aplicación (sí existe `fechaUltimaCorrelacion` por servidor); se usa la
   * hora local del cliente como aproximación hasta que se defina esa fuente. */
  protected readonly ultimaActualizacion = new Date().toLocaleString('es-CO', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  protected inicial(): string {
    const nombre = this.auth.usuarioActual()?.nombre ?? '?';
    return nombre.charAt(0).toUpperCase();
  }

  protected buscar(evento: SubmitEvent): void {
    evento.preventDefault();
    const form = evento.target as HTMLFormElement;
    const valor = (form.elements.namedItem('q') as HTMLInputElement)?.value?.trim();
    this.router.navigate(['/buscar'], { queryParams: { q: valor || null } });
  }
}
