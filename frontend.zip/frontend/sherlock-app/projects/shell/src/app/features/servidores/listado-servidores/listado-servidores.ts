import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { toSignal } from '@angular/core/rxjs-interop';
import { ServidoresService } from '../../../core/services/servidores.service';
import { FiltrosIdentidad } from '../../../core/models/comun.model';
import { ServidorResumen } from '../../../core/models/servidor.model';
import { IdentityFilterBar } from '../../../shared/identity-filter-bar/identity-filter-bar';
import { SeverityBadge } from '../../../shared/severity-badge/severity-badge';
import { EmptyState } from '../../../shared/empty-state/empty-state';
import { Paginator } from '../../../shared/paginator/paginator';

const TAMANO_PAGINA = 10;

/**
 * Listado de servidores en tarjetas (pantalla 02, HU-11, HU-12).
 * Los filtros se reflejan en los query params de la ruta (HU-12 CA3), lo que
 * permite compartir el enlace ya filtrado.
 */
@Component({
  selector: 'app-listado-servidores',
  imports: [RouterLink, IdentityFilterBar, SeverityBadge, EmptyState, Paginator],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 class="sk-heading">Servidores</h2>

    <app-identity-filter-bar
      [filtros]="filtros()"
      [mostrarTipoRiesgo]="false"
      (filtrosCambiados)="actualizarFiltros($event)"
      (limpiar)="limpiarFiltros()"
    />

    @if (cargando()) {
      <p>Cargando servidores…</p>
    } @else if (resultado()!.items.length === 0) {
      <app-empty-state
        titulo="Sin resultados."
        descripcion="No hay servidores que coincidan con la búsqueda o los filtros aplicados."
      />
    } @else {
      <div class="tarjetas">
        @for (servidor of resultado()!.items; track servidor.identidadId) {
          <a class="tarjeta sk-card" [routerLink]="['/servidores', servidor.identidadId]">
            <div class="tarjeta__cabecera">
              <span class="tarjeta__ip">{{ servidor.ip }}</span>
              <app-severity-badge [severidad]="servidor.severidad" />
            </div>
            @if (servidor.hostname) {
              <p class="tarjeta__hostname">{{ servidor.hostname }}</p>
            }
            <p class="tarjeta__score">{{ servidor.valorScore }}</p>
            <div class="tarjeta__conteos">
              @if (servidor.conteoCarpetas) {
                <span>Carpetas: {{ servidor.conteoCarpetas }}</span>
              }
              @if (servidor.conteoAdmins) {
                <span>Admins: {{ servidor.conteoAdmins }}</span>
              }
              @if (servidor.conteoAttackPaths) {
                <span>Paths: {{ servidor.conteoAttackPaths }}</span>
              }
              @if (servidor.conteoIoe) {
                <span>IOE: {{ servidor.conteoIoe }}</span>
              }
            </div>
          </a>
        }
      </div>

      <app-paginator
        [total]="resultado()!.total"
        [page]="filtros().page ?? 0"
        [size]="TAMANO_PAGINA"
        (cambiarPagina)="irAPagina($event)"
      />
    }
  `,
  styles: `
    .tarjetas { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
    .tarjeta { text-decoration: none; color: inherit; display: block; }
    .tarjeta__cabecera { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .tarjeta__ip { font-weight: 700; }
    .tarjeta__hostname { margin: 0 0 8px; color: var(--sk-color-text-muted); font-size: 0.8rem; }
    .tarjeta__score { font-size: 1.8rem; font-weight: 700; margin: 0 0 10px; }
    .tarjeta__conteos { display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.7rem; color: var(--sk-color-text-muted); }
  `,
})
export class ListadoServidores {
  protected readonly TAMANO_PAGINA = TAMANO_PAGINA;

  private readonly serviciosServidores = inject(ServidoresService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  protected readonly filtros = toSignal(
    this.route.queryParamMap.pipe(
      switchMap((params) =>
        of<FiltrosIdentidad>({
          q: params.get('q') ?? undefined,
          severidad: (params.get('severidad') as FiltrosIdentidad['severidad']) ?? undefined,
          tipoRiesgo: (params.get('tipoRiesgo') as FiltrosIdentidad['tipoRiesgo']) ?? undefined,
          page: params.get('page') ? Number(params.get('page')) : 0,
          size: TAMANO_PAGINA,
        }),
      ),
    ),
    { initialValue: { page: 0, size: TAMANO_PAGINA } as FiltrosIdentidad },
  );

  protected readonly cargando = signal(true);
  protected readonly resultado = toSignal(
    this.route.queryParamMap.pipe(
      switchMap((params) => {
        this.cargando.set(true);
        const filtros: FiltrosIdentidad = {
          q: params.get('q') ?? undefined,
          severidad: (params.get('severidad') as FiltrosIdentidad['severidad']) ?? undefined,
          tipoRiesgo: (params.get('tipoRiesgo') as FiltrosIdentidad['tipoRiesgo']) ?? undefined,
          page: params.get('page') ? Number(params.get('page')) : 0,
          size: TAMANO_PAGINA,
        };
        return this.serviciosServidores.listar(filtros).pipe(
          catchError(() => of({ items: [], total: 0, page: filtros.page ?? 0, size: TAMANO_PAGINA })),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: { items: [] as ServidorResumen[], total: 0, page: 0, size: TAMANO_PAGINA } },
  );

  protected actualizarFiltros(parcial: Partial<FiltrosIdentidad>): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { ...parcial, page: 0 },
      queryParamsHandling: 'merge',
    });
  }

  protected limpiarFiltros(): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: {} });
  }

  protected irAPagina(page: number): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: { page }, queryParamsHandling: 'merge' });
  }
}
