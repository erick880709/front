import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { toSignal } from '@angular/core/rxjs-interop';
import { UsuariosService } from '../../../core/services/usuarios.service';
import { FiltrosIdentidad } from '../../../core/models/comun.model';
import { UsuarioResumen } from '../../../core/models/usuario.model';
import { IdentityFilterBar } from '../../../shared/identity-filter-bar/identity-filter-bar';
import { SeverityBadge } from '../../../shared/severity-badge/severity-badge';
import { EmptyState } from '../../../shared/empty-state/empty-state';
import { Paginator } from '../../../shared/paginator/paginator';

const TAMANO_PAGINA = 10;

/** Listado de usuarios en tarjetas (pantalla 08, HU-11, HU-12). */
@Component({
  selector: 'app-listado-usuarios',
  imports: [RouterLink, IdentityFilterBar, SeverityBadge, EmptyState, Paginator],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 class="sk-heading">Usuarios</h2>

    <app-identity-filter-bar
      [filtros]="filtros()"
      [mostrarTipoRiesgo]="false"
      (filtrosCambiados)="actualizarFiltros($event)"
      (limpiar)="limpiarFiltros()"
    />

    @if (cargando()) {
      <p>Cargando usuarios…</p>
    } @else if (resultado()!.items.length === 0) {
      <app-empty-state
        titulo="Sin resultados."
        descripcion="No hay usuarios que coincidan con la búsqueda o los filtros aplicados."
      />
    } @else {
      <div class="tarjetas">
        @for (usuario of resultado()!.items; track usuario.identidadId) {
          <a class="tarjeta sk-card" [routerLink]="['/usuarios', usuario.identidadId]">
            <div class="tarjeta__cabecera">
              <span class="tarjeta__tipo">{{ usuario.tipoCuenta }}</span>
              <app-severity-badge [severidad]="usuario.severidad" />
            </div>
            <p class="tarjeta__nombre">{{ usuario.nombre }}</p>
            <p class="tarjeta__score">{{ usuario.valorScore }}</p>
            <div class="tarjeta__conteos">
              @if (usuario.conteoAdmin) {
                <span>Admin: {{ usuario.conteoAdmin }}</span>
              }
              @if (usuario.conteoControl) {
                <span>Control: {{ usuario.conteoControl }}</span>
              }
              @if (usuario.conteoGrupos) {
                <span>Grupos: {{ usuario.conteoGrupos }}</span>
              }
              @if (usuario.conteoIoe) {
                <span>IOE: {{ usuario.conteoIoe }}</span>
              }
            </div>
          </a>
        }
      </div>

      <app-paginator
        [total]="resultado()!.total"
        [page]="filtros().page ?? 0"
        [size]="TAMANO_PAGINA"
        (cambiarPagina)="irAPagina($event)"
      />
    }
  `,
  styles: `
    .tarjetas { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
    .tarjeta { text-decoration: none; color: inherit; display: block; }
    .tarjeta__cabecera { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .tarjeta__tipo { font-size: 0.7rem; text-transform: uppercase; color: var(--sk-color-text-muted); font-weight: 700; }
    .tarjeta__nombre { margin: 0 0 8px; font-weight: 700; }
    .tarjeta__score { font-size: 1.8rem; font-weight: 700; margin: 0 0 10px; }
    .tarjeta__conteos { display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.7rem; color: var(--sk-color-text-muted); }
  `,
})
export class ListadoUsuarios {
  protected readonly TAMANO_PAGINA = TAMANO_PAGINA;

  private readonly usuariosService = inject(UsuariosService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  protected readonly filtros = toSignal(
    this.route.queryParamMap.pipe(
      switchMap((params) =>
        of<FiltrosIdentidad>({
          q: params.get('q') ?? undefined,
          severidad: (params.get('severidad') as FiltrosIdentidad['severidad']) ?? undefined,
          page: params.get('page') ? Number(params.get('page')) : 0,
          size: TAMANO_PAGINA,
        }),
      ),
    ),
    { initialValue: { page: 0, size: TAMANO_PAGINA } as FiltrosIdentidad },
  );

  protected readonly cargando = signal(true);
  protected readonly resultado = toSignal(
    this.route.queryParamMap.pipe(
      switchMap((params) => {
        this.cargando.set(true);
        const filtros: FiltrosIdentidad = {
          q: params.get('q') ?? undefined,
          severidad: (params.get('severidad') as FiltrosIdentidad['severidad']) ?? undefined,
          page: params.get('page') ? Number(params.get('page')) : 0,
          size: TAMANO_PAGINA,
        };
        return this.usuariosService.listar(filtros).pipe(
          catchError(() => of({ items: [], total: 0, page: filtros.page ?? 0, size: TAMANO_PAGINA })),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: { items: [] as UsuarioResumen[], total: 0, page: 0, size: TAMANO_PAGINA } },
  );

  protected actualizarFiltros(parcial: Partial<FiltrosIdentidad>): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { ...parcial, page: 0 },
      queryParamsHandling: 'merge',
    });
  }

  protected limpiarFiltros(): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: {} });
  }

  protected irAPagina(page: number): void {
    this.router.navigate([], { relativeTo: this.route, queryParams: { page }, queryParamsHandling: 'merge' });
  }
}
