import { ChangeDetectionStrategy, Component, computed, inject, input, signal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { RutaAtaque, TipoIdentidad } from '../../core/models/comun.model';
import { ServidoresService } from '../../core/services/servidores.service';
import { UsuariosService } from '../../core/services/usuarios.service';
import { GruposService } from '../../core/services/grupos.service';
import { EmptyState } from '../../shared/empty-state/empty-state';

/**
 * Pestaña "Attack Paths" / "Grafo (ACL→Host)" en modo vacío (HU-16, ADR-005).
 *
 * Este componente es el mismo para servidores, usuarios y grupos (HU-16 CA1),
 * y SÍ llama al endpoint real correspondiente según `tipoIdentidad`
 * (`/servers/{id}/attack-paths`, `/users/{id}/graph`, `/groups/{id}/graph` —
 * ver `documento-funcional-tecnico-pantallas.html`, pantallas 05/09/11).
 * Hoy el backend no tiene ACL habilitada y siempre responde una lista vacía
 * o entradas con `estado: 'SIN_DATOS'` (contrato `RutaAtaque`), así que el
 * resultado visible es el estado vacío estandarizado con el mensaje de HU-16
 * CA2 — pero el llamado real ya existe, cumpliendo HU-16 CA3 ("el componente
 * de grafo... está construido y listo para recibir datos reales sin cambios
 * de contrato"): en cuanto ACL esté disponible y el backend empiece a
 * devolver rutas con `estado: 'DISPONIBLE'`, este mismo componente puede
 * evolucionar para renderizarlas (ej. con Cytoscape.js + Dagre, ya validado
 * por el prototipo — ver `EXPLICACION_CODIGO.md` §6) sin tocar el contrato.
 * Deliberadamente NO se agrega la dependencia `cytoscape` todavía: no hay
 * datos reales que graficar este ciclo.
 */
@Component({
  selector: 'app-attack-path-tab',
  imports: [EmptyState],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (cargando()) {
      <p>Cargando rutas de ataque…</p>
    } @else if (hayDatosReales()) {
      <!-- Punto de extensión: cuando ACL esté disponible, aquí se monta el
           grafo real (Cytoscape.js + Dagre) sobre el listado de rutas. -->
      <ul>
        @for (r of rutas(); track r.identidadOrigenId + r.identidadDestinoId) {
          <li>{{ r.identidadOrigenId }} → {{ r.identidadDestinoId }} ({{ r.tipoPermiso ?? 'sin tipo' }})</li>
        }
      </ul>
    } @else {
      <app-empty-state
        icono="🕸️"
        titulo="Rutas de ataque aún no disponibles."
        descripcion="Esta funcionalidad depende de la fuente de ACL de Active Directory, que aún no está habilitada en este ciclo (ver ADR-005). El módulo de grafo de rutas de ataque ya está construido y listo para mostrar datos reales apenas la fuente esté disponible, sin requerir cambios de contrato."
      />
    }
  `,
})
export class AttackPathTab {
  readonly tipoIdentidad = input.required<TipoIdentidad>();
  readonly identidadId = input.required<string>();

  private readonly servidoresService = inject(ServidoresService);
  private readonly usuariosService = inject(UsuariosService);
  private readonly gruposService = inject(GruposService);

  protected readonly cargando = signal(true);

  private readonly parametros = computed(() => ({
    tipo: this.tipoIdentidad(),
    id: this.identidadId(),
  }));
  private readonly parametros$ = toObservable(this.parametros);

  protected readonly rutas = toSignal(
    this.parametros$.pipe(
      switchMap(({ tipo, id }) => {
        this.cargando.set(true);
        const peticion$ =
          tipo === 'SERVIDOR'
            ? this.servidoresService.obtenerRutasAtaque(id)
            : tipo === 'USUARIO'
              ? this.usuariosService.obtenerGrafo(id)
              : this.gruposService.obtenerGrafo(id);
        return peticion$.pipe(
          catchError(() => of([] as RutaAtaque[])),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: [] as RutaAtaque[] },
  );

  protected hayDatosReales(): boolean {
    return this.rutas().some((r) => r.estado === 'DISPONIBLE');
  }
}
