import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { GruposService } from '../../../core/services/grupos.service';
import { GrupoDetalle } from '../../../core/models/grupo.model';
import { Hallazgo } from '../../../core/models/comun.model';
import { SeverityBadge } from '../../../shared/severity-badge/severity-badge';
import { MitrePanel } from '../../../shared/mitre-panel/mitre-panel';
import { EmptyState } from '../../../shared/empty-state/empty-state';
import { AttackPathTab } from '../../rutas-ataque/attack-path-tab';

type TabGrupo = 'IOE' | 'MEMBERS' | 'SERVERS_ADMIN' | 'SERVERS_CONTROL' | 'GRAFO';

const LARGO_TRUNCADO = 90;

/**
 * Vista de detalle de Grupo (pantalla 11, HU-15).
 * - CA1: score, severidad y técnicas MITRE agregadas del grupo.
 * - CA2: listado de miembros (origen Tenable/AD pendiente de definir con
 *   negocio, ver HU-15 — el contrato de `MiembroGrupo` ya queda preparado).
 */
@Component({
  selector: 'app-detalle-grupo',
  imports: [SeverityBadge, MitrePanel, EmptyState, AttackPathTab, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (grupo(); as g) {
      <header class="detalle-header sk-card">
        <div class="detalle-header__titulo">
          <h2 class="sk-heading">{{ g.nombre }}</h2>
          <span class="detalle-header__hostname">{{ g.tipoGrupo }}</span>
        </div>
        <dl class="detalle-header__meta">
          <div><dt>Score</dt><dd class="detalle-header__score">{{ g.valorScore }}</dd></div>
          <div><dt>Severidad</dt><dd><app-severity-badge [severidad]="g.severidad" /></dd></div>
          <div><dt>Miembros</dt><dd>{{ g.miembros.length }}</dd></div>
          <div><dt>Admin@host</dt><dd>{{ g.serversAdmin.length }}</dd></div>
          <div><dt>Control@host</dt><dd>{{ g.serversControl.length }}</dd></div>
          <div><dt>IOE</dt><dd>{{ g.ioe.length }}</dd></div>
        </dl>
      </header>

      <app-mitre-panel [tecnicas]="g.tecnicasMitre" />

      <nav class="tabs" aria-label="Sub-pestañas de detalle de grupo">
        @for (t of tabs; track t.id) {
          <button type="button" class="tabs__item" [class.tabs__item--activo]="tabActiva() === t.id" (click)="tabActiva.set(t.id)">
            {{ t.etiqueta }}
          </button>
        }
      </nav>

      <section class="tab-contenido">
        @switch (tabActiva()) {
          @case ('IOE') {
            @if (g.ioe.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin Indicadores de Exposición (IOE) para este grupo." />
            } @else {
              <div class="ioe-toolbar">
                <button type="button" class="sk-button sk-button--secondary" (click)="expandirTodo(g.ioe)">
                  Expandir todo
                </button>
                <button type="button" class="sk-button sk-button--secondary" (click)="colapsarTodo()">
                  Colapsar todo
                </button>
              </div>
              <table class="sk-table">
                <thead><tr><th>Título</th><th>Severidad</th><th>Detalle</th></tr></thead>
                <tbody>
                  @for (h of g.ioe; track h.hallazgoId) {
                    <tr>
                      <td>{{ h.titulo }}</td>
                      <td><app-severity-badge [severidad]="h.severidad" /></td>
                      @if (estaExpandida(h.hallazgoId)) {
                        <td>
                          {{ h.detalle }}
                          <button type="button" class="link-button" (click)="toggleFila(h.hallazgoId)">Ver menos</button>
                        </td>
                      } @else {
                        <td>
                          {{ truncar(h.detalle) }}
                          @if (esTruncable(h.detalle)) {
                            <button type="button" class="link-button" (click)="toggleFila(h.hallazgoId)">Ver más</button>
                          }
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('MEMBERS') {
            @if (g.miembros.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin miembros registrados para este grupo." />
            } @else {
              <ul class="lista-simple">
                @for (m of g.miembros; track m.identidadId) {
                  <li>
                    <a [routerLink]="m.tipo === 'GRUPO' ? ['/grupos', m.identidadId] : ['/usuarios', m.identidadId]">
                      {{ m.nombre }}
                    </a>
                    <span class="lista-simple__tipo">{{ m.tipo }}</span>
                  </li>
                }
              </ul>
            }
          }
          @case ('SERVERS_ADMIN') {
            @if (g.serversAdmin.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="El grupo no es administrador local de ningún servidor." />
            } @else {
              <table class="sk-table">
                <thead><tr><th>IP</th><th>Hostname</th></tr></thead>
                <tbody>
                  @for (s of g.serversAdmin; track s.identidadId) {
                    <tr>
                      <td><a [routerLink]="['/servidores', s.identidadId]">{{ s.ip }}</a></td>
                      <td>{{ s.hostname ?? '—' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('SERVERS_CONTROL') {
            @if (g.serversControl.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="El grupo no tiene control ACL sobre ningún servidor." />
            } @else {
              <table class="sk-table">
                <thead><tr><th>IP</th><th>Hostname</th></tr></thead>
                <tbody>
                  @for (s of g.serversControl; track s.identidadId) {
                    <tr>
                      <td><a [routerLink]="['/servidores', s.identidadId]">{{ s.ip }}</a></td>
                      <td>{{ s.hostname ?? '—' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('GRAFO') {
            <app-attack-path-tab tipoIdentidad="GRUPO" [identidadId]="g.identidadId" />
          }
        }
      </section>
    } @else if (cargando()) {
      <p>Cargando grupo…</p>
    } @else {
      <app-empty-state titulo="Grupo no encontrado." />
    }
  `,
  styles: `
    .detalle-header { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
    .detalle-header__hostname { display: block; color: var(--sk-color-text-muted); font-size: 0.85rem; }
    .detalle-header__meta { display: flex; gap: 24px; margin: 0; }
    .detalle-header__meta dt { font-size: 0.7rem; text-transform: uppercase; color: var(--sk-color-text-muted); }
    .detalle-header__meta dd { margin: 0; font-weight: 700; }
    .detalle-header__score { font-size: 1.4rem; }
    .tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--sk-color-border); margin-bottom: 16px; }
    .tabs__item { background: none; border: none; padding: 10px 14px; font-weight: 600; font-size: 0.85rem; color: var(--sk-color-text-muted); border-bottom: 3px solid transparent; cursor: pointer; }
    .tabs__item--activo { color: var(--sk-color-brand-black); border-bottom-color: var(--sk-color-brand-black); }
    .lista-simple { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px; }
    .lista-simple__tipo { margin-left: 8px; font-size: 0.7rem; color: var(--sk-color-text-muted); }
    .ioe-toolbar { display: flex; gap: 12px; margin-bottom: 12px; }
    .link-button {
      background: none;
      border: none;
      padding: 0;
      margin-left: 6px;
      color: var(--sk-color-brand-black);
      text-decoration: underline;
      font-size: 0.8rem;
      font-weight: 600;
      cursor: pointer;
    }
  `,
})
export class DetalleGrupo {
  private readonly route = inject(ActivatedRoute);
  private readonly gruposService = inject(GruposService);

  protected readonly cargando = signal(true);
  protected readonly tabActiva = signal<TabGrupo>('IOE');

  protected readonly tabs: { id: TabGrupo; etiqueta: string }[] = [
    { id: 'IOE', etiqueta: 'IOE' },
    { id: 'MEMBERS', etiqueta: 'Members' },
    { id: 'SERVERS_ADMIN', etiqueta: 'Servers (Admin)' },
    { id: 'SERVERS_CONTROL', etiqueta: 'Servers (Control)' },
    { id: 'GRAFO', etiqueta: 'Grafo (ACL→Host)' },
  ];

  protected readonly grupo = toSignal(
    this.route.paramMap.pipe(
      switchMap((params) => {
        this.cargando.set(true);
        return this.gruposService.obtenerDetalle(params.get('id')!).pipe(
          catchError(() => of(null)),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: null as GrupoDetalle | null },
  );

  // --- Expandir/Colapsar + "Ver más" del tab IOE (mockup 11) ---
  protected readonly filasExpandidas = signal<ReadonlySet<string>>(new Set());

  protected estaExpandida(id: string): boolean {
    return this.filasExpandidas().has(id);
  }

  protected toggleFila(id: string): void {
    const actual = new Set(this.filasExpandidas());
    if (actual.has(id)) {
      actual.delete(id);
    } else {
      actual.add(id);
    }
    this.filasExpandidas.set(actual);
  }

  protected expandirTodo(hallazgos: Hallazgo[]): void {
    this.filasExpandidas.set(new Set(hallazgos.map((h) => h.hallazgoId)));
  }

  protected colapsarTodo(): void {
    this.filasExpandidas.set(new Set());
  }

  protected esTruncable(texto: string | undefined): boolean {
    return (texto?.length ?? 0) > LARGO_TRUNCADO;
  }

  protected truncar(texto: string | undefined): string {
    return this.esTruncable(texto) ? `${texto?.slice(0, LARGO_TRUNCADO)}…` : (texto ?? '—');
  }
}
