import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { UsuariosService } from '../../../core/services/usuarios.service';
import { UsuarioDetalle } from '../../../core/models/usuario.model';
import { SeverityBadge } from '../../../shared/severity-badge/severity-badge';
import { MitrePanel } from '../../../shared/mitre-panel/mitre-panel';
import { EmptyState } from '../../../shared/empty-state/empty-state';
import { AttackPathTab } from '../../rutas-ataque/attack-path-tab';

type TabUsuario = 'IOE' | 'SERVERS_ADMIN' | 'SERVERS_CONTROL' | 'GROUPS' | 'GRAFO';

/**
 * Vista de detalle de Usuario (pantalla 09, HU-14).
 * - CA1: score, severidad, hallazgos por fuente y técnicas MITRE.
 * - CA2: grupos a los que pertenece, o estado vacío si la fuente de
 *   membresías de AD no está habilitada este ciclo.
 */
@Component({
  selector: 'app-detalle-usuario',
  imports: [SeverityBadge, MitrePanel, EmptyState, AttackPathTab, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (usuario(); as u) {
      <header class="detalle-header sk-card">
        <div class="detalle-header__titulo">
          <h2 class="sk-heading">{{ u.nombre }}</h2>
          <span class="detalle-header__hostname">{{ u.tipoCuenta }}</span>
        </div>
        <dl class="detalle-header__meta">
          <div><dt>Score</dt><dd class="detalle-header__score">{{ u.valorScore }}</dd></div>
          <div><dt>Severidad</dt><dd><app-severity-badge [severidad]="u.severidad" /></dd></div>
          <div><dt>Admin@host</dt><dd>{{ u.serversAdmin.length }}</dd></div>
          <div><dt>Control@host</dt><dd>{{ u.serversControl.length }}</dd></div>
          <div><dt>IOE</dt><dd>{{ u.ioe.length }}</dd></div>
          <div><dt>Grupos</dt><dd>{{ u.grupos.length }}</dd></div>
        </dl>
      </header>

      <app-mitre-panel [tecnicas]="u.tecnicasMitre" />

      <nav class="tabs" aria-label="Sub-pestañas de detalle de usuario">
        @for (t of tabs; track t.id) {
          <button type="button" class="tabs__item" [class.tabs__item--activo]="tabActiva() === t.id" (click)="tabActiva.set(t.id)">
            {{ t.etiqueta }}
          </button>
        }
      </nav>

      <section class="tab-contenido">
        @switch (tabActiva()) {
          @case ('IOE') {
            @if (u.ioe.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin Indicadores de Exposición (IOE) para este usuario." />
            } @else {
              <table class="sk-table">
                <thead><tr><th>Título</th><th>Severidad</th><th>Detalle</th></tr></thead>
                <tbody>
                  @for (h of u.ioe; track h.hallazgoId) {
                    <tr><td>{{ h.titulo }}</td><td><app-severity-badge [severidad]="h.severidad" /></td><td>{{ h.detalle }}</td></tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('SERVERS_ADMIN') {
            @if (u.serversAdmin.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="El usuario no es administrador local de ningún servidor." />
            } @else {
              <table class="sk-table">
                <thead><tr><th>IP</th><th>Hostname</th></tr></thead>
                <tbody>
                  @for (s of u.serversAdmin; track s.identidadId) {
                    <tr>
                      <td><a [routerLink]="['/servidores', s.identidadId]">{{ s.ip }}</a></td>
                      <td>{{ s.hostname ?? '—' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('SERVERS_CONTROL') {
            @if (u.serversControl.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="El usuario no tiene control ACL sobre ningún servidor." />
            } @else {
              <table class="sk-table">
                <thead><tr><th>IP</th><th>Hostname</th></tr></thead>
                <tbody>
                  @for (s of u.serversControl; track s.identidadId) {
                    <tr>
                      <td><a [routerLink]="['/servidores', s.identidadId]">{{ s.ip }}</a></td>
                      <td>{{ s.hostname ?? '—' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
          @case ('GROUPS') {
            @if (u.grupos.length === 0) {
              <app-empty-state
                titulo="Sin resultados."
                descripcion="Sin datos de membresía de grupos disponibles en las fuentes habilitadas este ciclo."
              />
            } @else {
              <ul class="lista-simple">
                @for (g of u.grupos; track g.identidadId) {
                  <li><a [routerLink]="['/grupos', g.identidadId]">{{ g.nombre }}</a></li>
                }
              </ul>
            }
          }
          @case ('GRAFO') {
            <app-attack-path-tab tipoIdentidad="USUARIO" [identidadId]="u.identidadId" />
          }
        }
      </section>
    } @else if (cargando()) {
      <p>Cargando usuario…</p>
    } @else {
      <app-empty-state titulo="Usuario no encontrado." />
    }
  `,
  styles: `
    .detalle-header { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
    .detalle-header__hostname { display: block; color: var(--sk-color-text-muted); font-size: 0.85rem; }
    .detalle-header__meta { display: flex; gap: 24px; margin: 0; }
    .detalle-header__meta dt { font-size: 0.7rem; text-transform: uppercase; color: var(--sk-color-text-muted); }
    .detalle-header__meta dd { margin: 0; font-weight: 700; }
    .detalle-header__score { font-size: 1.4rem; }
    .tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--sk-color-border); margin-bottom: 16px; }
    .tabs__item { background: none; border: none; padding: 10px 14px; font-weight: 600; font-size: 0.85rem; color: var(--sk-color-text-muted); border-bottom: 3px solid transparent; cursor: pointer; }
    .tabs__item--activo { color: var(--sk-color-brand-black); border-bottom-color: var(--sk-color-brand-black); }
    .lista-simple { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px; }
  `,
})
export class DetalleUsuario {
  private readonly route = inject(ActivatedRoute);
  private readonly usuariosService = inject(UsuariosService);

  protected readonly cargando = signal(true);
  protected readonly tabActiva = signal<TabUsuario>('IOE');

  protected readonly tabs: { id: TabUsuario; etiqueta: string }[] = [
    { id: 'IOE', etiqueta: 'IOE' },
    { id: 'SERVERS_ADMIN', etiqueta: 'Servers (Admin)' },
    { id: 'SERVERS_CONTROL', etiqueta: 'Servers (Control)' },
    { id: 'GROUPS', etiqueta: 'Groups' },
    { id: 'GRAFO', etiqueta: 'Grafo (ACL→Host)' },
  ];

  protected readonly usuario = toSignal(
    this.route.paramMap.pipe(
      switchMap((params) => {
        this.cargando.set(true);
        return this.usuariosService.obtenerDetalle(params.get('id')!).pipe(
          catchError(() => of(null)),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: null as UsuarioDetalle | null },
  );
}
