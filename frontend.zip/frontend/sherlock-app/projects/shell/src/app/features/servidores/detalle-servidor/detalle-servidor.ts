import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { catchError, finalize, of, switchMap } from 'rxjs';
import { NgTemplateOutlet } from '@angular/common';
import { ServidoresService } from '../../../core/services/servidores.service';
import { ServidorDetalle } from '../../../core/models/servidor.model';
import { Hallazgo } from '../../../core/models/comun.model';
import { SeverityBadge } from '../../../shared/severity-badge/severity-badge';
import { MitrePanel } from '../../../shared/mitre-panel/mitre-panel';
import { EmptyState } from '../../../shared/empty-state/empty-state';
import { AttackPathTab } from '../../rutas-ataque/attack-path-tab';

type TabServidor = 'CARPETAS' | 'ADMINS' | 'ATTACK_PATHS' | 'VIRTUAL_PATCHING' | 'IOE' | 'SPIDER';

/** Filtro de Admins aplicado, atado al `identidadId` para el que se pidió,
 * de forma que un cambio de servidor (navegación) no arrastre el filtro
 * anterior aunque el signal no se reinicie explícitamente. */
interface FiltroAdmins {
  identidadId: string;
  anomalia: string;
  datos: Hallazgo[];
}

const LARGO_TRUNCADO = 90;

/**
 * Vista de detalle de Servidor (pantallas 03-07, HU-13).
 * - CA1: encabezado (IP, SO si está disponible, owner), score, severidad y MITRE.
 * - CA2: hallazgos separados por fuente (Tenable / Virtual Patching).
 * - CA3: Carpetas, Admins, Spider e IOE muestran el estado vacío estandarizado
 *   cuando no hay datos para este ciclo, nunca un error.
 */
@Component({
  selector: 'app-detalle-servidor',
  imports: [SeverityBadge, MitrePanel, EmptyState, AttackPathTab, NgTemplateOutlet],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (servidor(); as s) {
      <header class="detalle-header sk-card">
        <div class="detalle-header__titulo">
          <h2 class="sk-heading">{{ s.ip }}</h2>
          @if (s.hostname) {
            <span class="detalle-header__hostname">{{ s.hostname }}</span>
          }
          @if (s.attackScenario) {
            <span class="detalle-header__escenario">Attack Scenario: {{ s.attackScenario }}</span>
          }
        </div>

        <button type="button" class="sk-button sk-button--secondary detalle-header__exportar" (click)="exportarPdf()">
          PDF Detalle
        </button>

        <dl class="detalle-header__meta">
          @if (s.sistemaOperativo) {
            <div><dt>SO</dt><dd>{{ s.sistemaOperativo }}</dd></div>
          }
          @if (s.owner) {
            <div>
              <dt>Owner</dt>
              <dd class="detalle-header__owner">
                <span class="detalle-header__avatar" aria-hidden="true">{{ inicialOwner(s.owner) }}</span>
                {{ s.owner }}
              </dd>
            </div>
          }
          <div><dt>Score</dt><dd class="detalle-header__score">{{ s.valorScore }}</dd></div>
          <div><dt>Severidad</dt><dd><app-severity-badge [severidad]="s.severidad" /></dd></div>
          <div><dt>Carpetas</dt><dd>{{ s.carpetas.length }}</dd></div>
          <div><dt>Admins</dt><dd>{{ s.admins.length }}</dd></div>
          <div><dt>Spider</dt><dd>{{ s.spider.length }}</dd></div>
          <div><dt>IOE</dt><dd>{{ s.ioe.length }}</dd></div>
        </dl>
      </header>

      <app-mitre-panel [tecnicas]="s.tecnicasMitre" />

      <nav class="tabs" aria-label="Sub-pestañas de detalle de servidor">
        @for (t of tabs; track t.id) {
          <button
            type="button"
            class="tabs__item"
            [class.tabs__item--activo]="tabActiva() === t.id"
            (click)="tabActiva.set(t.id)"
          >
            {{ t.etiqueta }}
          </button>
        }
      </nav>

      <section class="tab-contenido">
        @switch (tabActiva()) {
          @case ('CARPETAS') {
            @if (s.carpetas.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin hallazgos de Carpetas para este servidor." />
            } @else {
              <ng-container [ngTemplateOutlet]="tablaHallazgos" [ngTemplateOutletContext]="{ $implicit: s.carpetas }" />
            }
          }
          @case ('ADMINS') {
            <div class="filtro-anomalia">
              <select
                class="filtro-anomalia__select"
                [value]="anomaliaActual()"
                (change)="onFiltroAnomaliaChange($event, s.identidadId)"
                aria-label="Filtrar por anomalía"
              >
                <option value="">Filtrar por anomalía: Todas</option>
                @for (op of opcionesAnomalia(); track op) {
                  <option [value]="op">{{ op }}</option>
                }
              </select>
              <button type="button" class="sk-button sk-button--secondary" (click)="limpiarFiltroAnomalia()">
                Limpiar
              </button>
            </div>
            @if (adminsMostrados().length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin hallazgos de Admins locales para este servidor." />
            } @else {
              <ng-container [ngTemplateOutlet]="tablaHallazgos" [ngTemplateOutletContext]="{ $implicit: adminsMostrados() }" />
            }
          }
          @case ('ATTACK_PATHS') {
            <app-attack-path-tab tipoIdentidad="SERVIDOR" [identidadId]="s.identidadId" />
          }
          @case ('VIRTUAL_PATCHING') {
            @if (s.hallazgosVirtualPatching.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin hallazgos de Virtual Patching para este servidor." />
            } @else {
              <ng-container
                [ngTemplateOutlet]="tablaHallazgos"
                [ngTemplateOutletContext]="{ $implicit: s.hallazgosVirtualPatching }"
              />
            }
          }
          @case ('IOE') {
            @if (s.ioe.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin Indicadores de Exposición (IOE) para este servidor." />
            } @else {
              <div class="ioe-toolbar">
                <button type="button" class="sk-button sk-button--secondary" (click)="expandirTodo(s.ioe)">
                  Expandir todo
                </button>
                <button type="button" class="sk-button sk-button--secondary" (click)="colapsarTodo()">
                  Colapsar todo
                </button>
              </div>
              <ng-container [ngTemplateOutlet]="tablaIoe" [ngTemplateOutletContext]="{ $implicit: s.ioe }" />
            }
          }
          @case ('SPIDER') {
            @if (s.spider.length === 0) {
              <app-empty-state titulo="Sin resultados." descripcion="Sin datos de Spider (descubrimiento AWS) para este servidor." />
            } @else {
              <ng-container [ngTemplateOutlet]="tablaHallazgos" [ngTemplateOutletContext]="{ $implicit: s.spider }" />
            }
          }
        }
      </section>

      @if (s.hallazgosTenable.length > 0) {
        <section class="sk-card">
          <h3 class="sk-heading">Hallazgos Tenable</h3>
          <ng-container [ngTemplateOutlet]="tablaHallazgos" [ngTemplateOutletContext]="{ $implicit: s.hallazgosTenable }" />
        </section>
      }

      <ng-template #tablaHallazgos let-hallazgos>
        <table class="sk-table">
          <thead>
            <tr>
              <th>Título</th>
              <th>Severidad</th>
              <th>Detalle</th>
              <th>Recomendación</th>
            </tr>
          </thead>
          <tbody>
            @for (h of hallazgos; track h.hallazgoId) {
              <tr>
                <td>{{ h.titulo }}</td>
                <td><app-severity-badge [severidad]="h.severidad" /></td>
                <td>{{ h.detalle }}</td>
                <td>{{ h.recomendacion ?? '—' }}</td>
              </tr>
            }
          </tbody>
        </table>
      </ng-template>

      <ng-template #tablaIoe let-hallazgos>
        <table class="sk-table">
          <thead>
            <tr>
              <th>Título</th>
              <th>Severidad</th>
              <th>Detalle</th>
              <th>Recomendación</th>
            </tr>
          </thead>
          <tbody>
            @for (h of hallazgos; track h.hallazgoId) {
              <tr>
                <td>{{ h.titulo }}</td>
                <td><app-severity-badge [severidad]="h.severidad" /></td>
                @if (estaExpandida(h.hallazgoId)) {
                  <td>{{ h.detalle }}</td>
                  <td>
                    {{ h.recomendacion ?? '—' }}
                    <button type="button" class="link-button" (click)="toggleFila(h.hallazgoId)">Ver menos</button>
                  </td>
                } @else {
                  <td>{{ truncar(h.detalle) }}</td>
                  <td>
                    {{ truncar(h.recomendacion ?? '—') }}
                    @if (esTruncable(h.detalle) || esTruncable(h.recomendacion)) {
                      <button type="button" class="link-button" (click)="toggleFila(h.hallazgoId)">Ver más</button>
                    }
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
      </ng-template>
    } @else if (cargando()) {
      <p>Cargando servidor…</p>
    } @else {
      <app-empty-state titulo="Servidor no encontrado." />
    }
  `,
  styles: `
    .detalle-header { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
    .detalle-header__hostname { display: block; color: var(--sk-color-text-muted); font-size: 0.85rem; }
    .detalle-header__escenario {
      display: inline-block;
      margin-top: 6px;
      padding: 3px 10px;
      border-radius: 6px;
      background: var(--sk-color-info);
      color: #fff;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }
    .detalle-header__exportar { align-self: flex-start; }
    .detalle-header__meta { display: flex; flex-wrap: wrap; gap: 24px; margin: 0; }
    .detalle-header__meta dt { font-size: 0.7rem; text-transform: uppercase; color: var(--sk-color-text-muted); }
    .detalle-header__meta dd { margin: 0; font-weight: 700; }
    .detalle-header__score { font-size: 1.4rem; }
    .detalle-header__owner { display: flex; align-items: center; gap: 8px; }
    .detalle-header__avatar {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: var(--sk-color-info);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 0.75rem;
      flex-shrink: 0;
    }
    .tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--sk-color-border); margin-bottom: 16px; }
    .tabs__item { background: none; border: none; padding: 10px 14px; font-weight: 600; font-size: 0.85rem; color: var(--sk-color-text-muted); border-bottom: 3px solid transparent; cursor: pointer; }
    .tabs__item--activo { color: var(--sk-color-brand-black); border-bottom-color: var(--sk-color-brand-black); }
    .filtro-anomalia { display: flex; flex-wrap: wrap; gap: 12px; align-items: center; margin-bottom: 16px; }
    .filtro-anomalia__select {
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.85rem;
      color: var(--sk-color-text);
    }
    .ioe-toolbar { display: flex; gap: 12px; margin-bottom: 12px; }
    .link-button {
      background: none;
      border: none;
      padding: 0;
      margin-left: 6px;
      color: var(--sk-color-brand-black);
      text-decoration: underline;
      font-size: 0.8rem;
      font-weight: 600;
      cursor: pointer;
    }
  `,
})
export class DetalleServidor {
  private readonly route = inject(ActivatedRoute);
  private readonly servidoresService = inject(ServidoresService);

  protected readonly cargando = signal(true);
  protected readonly tabActiva = signal<TabServidor>('CARPETAS');

  protected readonly tabs: { id: TabServidor; etiqueta: string }[] = [
    { id: 'CARPETAS', etiqueta: 'Carpetas' },
    { id: 'ADMINS', etiqueta: 'Admins' },
    { id: 'ATTACK_PATHS', etiqueta: 'Attack Paths' },
    { id: 'VIRTUAL_PATCHING', etiqueta: 'Virtual Patching' },
    { id: 'IOE', etiqueta: 'IOE' },
    { id: 'SPIDER', etiqueta: 'Spider' },
  ];

  protected readonly servidor = toSignal(
    this.route.paramMap.pipe(
      switchMap((params) => {
        this.cargando.set(true);
        const id = params.get('id')!;
        return this.servidoresService.obtenerDetalle(id).pipe(
          catchError(() => of(null)),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: null as ServidorDetalle | null },
  );

  // --- Filtro "Filtrar por anomalía" del tab Admins (mockup 04) ---
  protected readonly filtroAdmins = signal<FiltroAdmins | null>(null);

  protected readonly opcionesAnomalia = computed(() => {
    const s = this.servidor();
    return s ? [...new Set(s.admins.map((a) => a.titulo))] : [];
  });

  protected readonly anomaliaActual = computed(() => {
    const s = this.servidor();
    const filtro = this.filtroAdmins();
    return s && filtro && filtro.identidadId === s.identidadId ? filtro.anomalia : '';
  });

  protected readonly adminsMostrados = computed(() => {
    const s = this.servidor();
    if (!s) return [];
    const filtro = this.filtroAdmins();
    return filtro && filtro.identidadId === s.identidadId ? filtro.datos : s.admins;
  });

  protected onFiltroAnomaliaChange(evento: Event, identidadId: string): void {
    const anomalia = (evento.target as HTMLSelectElement).value;
    if (!anomalia) {
      this.filtroAdmins.set(null);
      return;
    }
    this.servidoresService.obtenerAdmins(identidadId, anomalia).subscribe((datos) => {
      this.filtroAdmins.set({ identidadId, anomalia, datos });
    });
  }

  protected limpiarFiltroAnomalia(): void {
    this.filtroAdmins.set(null);
  }

  // --- Expandir/Colapsar + "Ver más" del tab IOE (mockup 06) ---
  protected readonly filasExpandidas = signal<ReadonlySet<string>>(new Set());

  protected estaExpandida(id: string): boolean {
    return this.filasExpandidas().has(id);
  }

  protected toggleFila(id: string): void {
    const actual = new Set(this.filasExpandidas());
    if (actual.has(id)) {
      actual.delete(id);
    } else {
      actual.add(id);
    }
    this.filasExpandidas.set(actual);
  }

  protected expandirTodo(hallazgos: Hallazgo[]): void {
    this.filasExpandidas.set(new Set(hallazgos.map((h) => h.hallazgoId)));
  }

  protected colapsarTodo(): void {
    this.filasExpandidas.set(new Set());
  }

  protected esTruncable(texto: string | undefined): boolean {
    return (texto?.length ?? 0) > LARGO_TRUNCADO;
  }

  protected truncar(texto: string | undefined): string {
    return this.esTruncable(texto) ? `${texto?.slice(0, LARGO_TRUNCADO)}…` : (texto ?? '—');
  }

  // --- Owner: avatar con inicial (mismo patrón que shell-layout.ts) ---
  protected inicialOwner(owner: string): string {
    return owner.charAt(0).toUpperCase();
  }

  // --- Exportación PDF (mockup: botón "PDF Detalle") ---
  protected exportarPdf(): void {
    const s = this.servidor();
    if (!s) return;
    this.servidoresService.exportar('pdf', { q: s.ip }).subscribe((blob) => {
      const url = URL.createObjectURL(blob);
      const enlace = document.createElement('a');
      enlace.href = url;
      enlace.download = `servidor-${s.ip}.pdf`;
      enlace.click();
      URL.revokeObjectURL(url);
    });
  }
}
