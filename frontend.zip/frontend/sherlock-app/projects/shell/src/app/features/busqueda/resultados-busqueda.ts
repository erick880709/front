import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of, switchMap } from 'rxjs';
import { ServidoresService } from '../../core/services/servidores.service';
import { UsuariosService } from '../../core/services/usuarios.service';
import { GruposService } from '../../core/services/grupos.service';
import { SeverityBadge } from '../../shared/severity-badge/severity-badge';
import { EmptyState } from '../../shared/empty-state/empty-state';

interface ResultadoBusqueda {
  identidadId: string;
  nombre: string;
  tipo: 'SERVIDOR' | 'USUARIO' | 'GRUPO';
  severidad: 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA';
  ruta: string[];
}

/**
 * Búsqueda global de identidades (HU-11): coincidencia parcial por
 * nombre/IP/owner sobre los 3 módulos a la vez, sin recargar la página
 * completa (CA2), con el estado vacío estandarizado si no hay coincidencias
 * (CA3).
 */
@Component({
  selector: 'app-resultados-busqueda',
  imports: [SeverityBadge, EmptyState, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 class="sk-heading">Resultados de búsqueda: "{{ termino() }}"</h2>

    @if (cargando()) {
      <p>Buscando…</p>
    } @else if (resultados().length === 0) {
      <app-empty-state
        titulo="Sin resultados."
        descripcion="No se encontraron identidades que coincidan con la búsqueda."
      />
    } @else {
      <ul class="lista-resultados">
        @for (r of resultados(); track r.identidadId) {
          <li class="lista-resultados__item sk-card">
            <a [routerLink]="r.ruta">
              <span class="lista-resultados__tipo">{{ r.tipo }}</span>
              <span class="lista-resultados__nombre">{{ r.nombre }}</span>
            </a>
            <app-severity-badge [severidad]="r.severidad" />
          </li>
        }
      </ul>
    }
  `,
  styles: `
    .lista-resultados { list-style: none; margin: 16px 0 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
    .lista-resultados__item { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .lista-resultados__item a { display: flex; flex-direction: column; text-decoration: none; color: inherit; }
    .lista-resultados__tipo { font-size: 0.65rem; text-transform: uppercase; color: var(--sk-color-text-muted); font-weight: 700; }
    .lista-resultados__nombre { font-weight: 600; }
  `,
})
export class ResultadosBusqueda {
  private readonly route = inject(ActivatedRoute);
  private readonly servidoresService = inject(ServidoresService);
  private readonly usuariosService = inject(UsuariosService);
  private readonly gruposService = inject(GruposService);

  protected readonly cargando = signal(true);

  protected readonly termino = toSignal(
    this.route.queryParamMap.pipe(switchMap((params) => of(params.get('q') ?? ''))),
    { initialValue: '' },
  );

  protected readonly resultados = toSignal(
    this.route.queryParamMap.pipe(
      switchMap((params) => {
        const q = params.get('q') ?? '';
        this.cargando.set(true);
        if (!q) {
          this.cargando.set(false);
          return of([] as ResultadoBusqueda[]);
        }
        return forkJoin({
          servidores: this.servidoresService.listar({ q, page: 0, size: 5 }).pipe(catchError(() => of({ items: [], total: 0, page: 0, size: 5 }))),
          usuarios: this.usuariosService.listar({ q, page: 0, size: 5 }).pipe(catchError(() => of({ items: [], total: 0, page: 0, size: 5 }))),
          grupos: this.gruposService.listar({ q, page: 0, size: 5 }).pipe(catchError(() => of({ items: [], total: 0, page: 0, size: 5 }))),
        }).pipe(
          switchMap(({ servidores, usuarios, grupos }) => {
            const combinados: ResultadoBusqueda[] = [
              ...servidores.items.map((s) => ({
                identidadId: s.identidadId,
                nombre: s.hostname ?? s.ip,
                tipo: 'SERVIDOR' as const,
                severidad: s.severidad,
                ruta: ['/servidores', s.identidadId],
              })),
              ...usuarios.items.map((u) => ({
                identidadId: u.identidadId,
                nombre: u.nombre,
                tipo: 'USUARIO' as const,
                severidad: u.severidad,
                ruta: ['/usuarios', u.identidadId],
              })),
              ...grupos.items.map((g) => ({
                identidadId: g.identidadId,
                nombre: g.nombre,
                tipo: 'GRUPO' as const,
                severidad: g.severidad,
                ruta: ['/grupos', g.identidadId],
              })),
            ];
            return of(combinados);
          }),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: [] as ResultadoBusqueda[] },
  );
}
