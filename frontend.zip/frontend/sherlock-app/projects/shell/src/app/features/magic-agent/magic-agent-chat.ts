import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { catchError, of } from 'rxjs';
import { MagicAgentService } from '../../core/services/magic-agent.service';
import { MagicAgentMensaje } from '../../core/models/magic-agent.model';

/**
 * Chat UI mínimo del Sherlock Magic Agent (HU-23, prioridad Baja, alcance
 * mínimo). Solo shell de UI (caja de mensajes, input, tarjetas de
 * respuesta): sin lógica de matching de intención ni de entidades en el
 * frontend (CA1: "responde con base en reglas... indicando explícitamente
 * en la UI que no usa un LLM" — el aviso "Rule-Based" es puramente de UI, la
 * clasificación real vive en el Monolito de Negocio, RF-014 a RF-017).
 *
 * CA2 (solo lectura, sin crear excepciones ni reasignar responsables) se
 * cumple por diseño: este componente no expone ninguna acción de escritura,
 * solo envía la pregunta y renderiza la respuesta.
 */
@Component({
  selector: 'app-magic-agent-chat',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="magic-agent sk-card">
      <header class="magic-agent__header">
        <h3 class="sk-heading">Sherlock Magic Agent</h3>
        <span class="magic-agent__badge">Rule-Based · no es un LLM</span>
      </header>

      <div class="magic-agent__mensajes" role="log" aria-live="polite">
        @if (mensajes().length === 0) {
          <p class="magic-agent__vacio">
            Pregunta en lenguaje natural por el riesgo de un servidor, usuario o grupo
            (ej. "¿cuál es el riesgo de svc_backup?").
          </p>
        }
        @for (m of mensajes(); track m.id) {
          <div class="magic-agent__mensaje" [class.magic-agent__mensaje--agente]="m.emisor === 'AGENTE'">
            <p class="magic-agent__texto">{{ m.texto }}</p>
            @if (m.noResuelto) {
              <p class="magic-agent__aviso">
                No se pudo identificar la identidad consultada. Intenta con el nombre exacto, IP u owner.
              </p>
            }
            @if (m.tarjeta) {
              <div class="magic-agent__tarjeta">
                <p>{{ m.tarjeta.resumen }}</p>
                @if (m.tarjeta.tecnicasMitre?.length) {
                  <p class="magic-agent__tarjeta-mitre">
                    MITRE: {{ m.tarjeta.tecnicasMitre!.join(', ') }}
                  </p>
                }
                @if (m.tarjeta.evidencia?.length) {
                  <ul class="magic-agent__tarjeta-evidencia">
                    @for (e of m.tarjeta.evidencia!; track e) {
                      <li>{{ e }}</li>
                    }
                  </ul>
                }
              </div>
            }
          </div>
        }
      </div>

      <form class="magic-agent__form" (submit)="enviar($event)">
        <input
          name="pregunta"
          type="text"
          [(ngModel)]="preguntaActual"
          placeholder="Escribe tu consulta..."
          aria-label="Consulta al Sherlock Magic Agent"
          [disabled]="enviando()"
        />
        <button type="submit" class="sk-button sk-button--primary" [disabled]="enviando() || !preguntaActual.trim()">
          Enviar
        </button>
      </form>
    </section>
  `,
  styles: `
    .magic-agent { display: flex; flex-direction: column; gap: 12px; max-width: 480px; }
    .magic-agent__header { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .magic-agent__badge {
      font-size: 0.65rem;
      font-weight: 700;
      text-transform: uppercase;
      color: var(--sk-color-text-muted);
      background: var(--sk-color-surface-alt);
      padding: 3px 8px;
      border-radius: 10px;
    }
    .magic-agent__mensajes { display: flex; flex-direction: column; gap: 10px; max-height: 320px; overflow-y: auto; }
    .magic-agent__vacio { color: var(--sk-color-text-muted); font-size: 0.85rem; }
    .magic-agent__mensaje { align-self: flex-end; background: var(--sk-color-surface-alt); border-radius: 10px; padding: 8px 12px; max-width: 85%; }
    .magic-agent__mensaje--agente { align-self: flex-start; background: var(--sk-color-info); color: #fff; }
    .magic-agent__texto { margin: 0; font-size: 0.85rem; }
    .magic-agent__aviso { margin: 6px 0 0; font-size: 0.75rem; font-style: italic; }
    .magic-agent__tarjeta { margin-top: 8px; background: rgba(255, 255, 255, 0.15); border-radius: 8px; padding: 8px; font-size: 0.75rem; }
    .magic-agent__tarjeta-mitre { font-weight: 700; }
    .magic-agent__tarjeta-evidencia { margin: 4px 0 0; padding-left: 16px; }
    .magic-agent__form { display: flex; gap: 8px; }
    .magic-agent__form input { flex: 1; border: none; border-bottom: 2px solid var(--sk-color-border); background: transparent; padding: 8px 4px; }
  `,
})
export class MagicAgentChat {
  private readonly magicAgentService = inject(MagicAgentService);

  protected preguntaActual = '';
  protected readonly enviando = signal(false);
  protected readonly mensajes = signal<MagicAgentMensaje[]>([]);

  protected enviar(evento: SubmitEvent): void {
    evento.preventDefault();
    const texto = this.preguntaActual.trim();
    if (!texto) return;

    const idUsuario = crypto.randomUUID();
    this.mensajes.update((actual) => [
      ...actual,
      { id: idUsuario, emisor: 'USUARIO', texto, fecha: new Date() },
    ]);
    this.preguntaActual = '';
    this.enviando.set(true);

    this.magicAgentService
      .consultar(texto)
      .pipe(
        catchError(() =>
          of({
            resumen: '',
            tecnicasMitre: [],
            evidencia: [],
            identidadResuelta: false,
          }),
        ),
      )
      .subscribe((respuesta) => {
        this.enviando.set(false);
        this.mensajes.update((actual) => [
          ...actual,
          {
            id: crypto.randomUUID(),
            emisor: 'AGENTE',
            texto: respuesta.identidadResuelta ? respuesta.resumen : 'No pude resolver esa consulta.',
            fecha: new Date(),
            noResuelto: !respuesta.identidadResuelta,
            tarjeta: respuesta.identidadResuelta
              ? {
                  resumen: respuesta.resumen,
                  tecnicasMitre: respuesta.tecnicasMitre,
                  evidencia: respuesta.evidencia,
                }
              : undefined,
          },
        ]);
      });
  }
}
