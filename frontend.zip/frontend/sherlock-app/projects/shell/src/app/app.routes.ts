import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { authGuard } from './core/guards/auth.guard';
import { ShellLayout } from './layout/shell-layout/shell-layout';

/**
 * Rutas del shell (HU-10: navegación entre módulos, siempre montada bajo
 * `authGuard` — stub de Entra ID, ver core/guards/auth.guard.ts).
 *
 * La ruta `dashboard` es la prueba de concepto de Module Federation exigida
 * por TT-13/ADR-008: en vez de importar el componente del proyecto
 * `dashboard` de forma estática, se carga en runtime desde su
 * `remoteEntry.json` vía `loadRemoteModule` (native federation) — el shell
 * queda demostrablemente capaz de cargar un remoto, aun cuando este ciclo se
 * despliegue todo como un único bundle.
 *
 * El resto de features (servidores/usuarios/grupos/rutas-ataque/magic-agent)
 * vive dentro del propio proyecto `shell` este ciclo: TT-13 solo exige "al
 * menos un remoto de referencia", no que cada módulo sea su propio remoto.
 */
export const routes: Routes = [
  {
    path: '',
    component: ShellLayout,
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () =>
          loadRemoteModule('dashboard', './Component').then((m) => m.App),
      },
      {
        path: 'servidores',
        children: [
          {
            path: '',
            loadComponent: () =>
              import('./features/servidores/listado-servidores/listado-servidores').then(
                (m) => m.ListadoServidores,
              ),
          },
          {
            path: ':id',
            loadComponent: () =>
              import('./features/servidores/detalle-servidor/detalle-servidor').then((m) => m.DetalleServidor),
          },
        ],
      },
      {
        path: 'usuarios',
        children: [
          {
            path: '',
            loadComponent: () =>
              import('./features/usuarios/listado-usuarios/listado-usuarios').then((m) => m.ListadoUsuarios),
          },
          {
            path: ':id',
            loadComponent: () =>
              import('./features/usuarios/detalle-usuario/detalle-usuario').then((m) => m.DetalleUsuario),
          },
        ],
      },
      {
        path: 'grupos',
        children: [
          {
            path: '',
            loadComponent: () =>
              import('./features/grupos/listado-grupos/listado-grupos').then((m) => m.ListadoGrupos),
          },
          {
            path: ':id',
            loadComponent: () =>
              import('./features/grupos/detalle-grupo/detalle-grupo').then((m) => m.DetalleGrupo),
          },
        ],
      },
      {
        path: 'buscar',
        loadComponent: () =>
          import('./features/busqueda/resultados-busqueda').then((m) => m.ResultadosBusqueda),
      },
      {
        // HU-23 (Baja, alcance mínimo): el widget del Magic Agent se muestra
        // en la pantalla 01 (dashboard, remoto Module Federation) con un
        // enlace a esta ruta para la conversación completa — se mantiene una
        // sola implementación del chat en el shell en vez de duplicarla
        // dentro del remoto `dashboard` (ver `projects/dashboard/src/app/app.ts`).
        path: 'asistente',
        loadComponent: () =>
          import('./features/magic-agent/magic-agent-chat').then((m) => m.MagicAgentChat),
      },
    ],
  },
];
