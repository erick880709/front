import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FiltrosIdentidad, Severidad, TipoRiesgo } from '../../core/models/comun.model';

/**
 * Barra de búsqueda + filtros combinables de severidad y tipo de riesgo
 * (HU-11, HU-12), reutilizada en los 3 listados (Servidores/Usuarios/Grupos).
 *
 * Es un componente puro de presentación: no toca la URL directamente. Cada
 * página de listado (ej. `ListadoServidores`) es quien sincroniza
 * `filtros`/`filtrosCambiados` con los query params de la ruta (HU-12 CA3),
 * para no acoplar este componente compartido al router de una feature en
 * particular.
 */
@Component({
  selector: 'app-identity-filter-bar',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="filter-bar">
      <input
        class="filter-bar__search"
        type="search"
        [ngModel]="filtros().q ?? ''"
        (ngModelChange)="onCambio({ q: $event || undefined })"
        placeholder="Buscar por nombre, IP u owner..."
        aria-label="Búsqueda global de identidades"
      />

      <select
        class="filter-bar__select"
        [ngModel]="filtros().severidad ?? ''"
        (ngModelChange)="onCambio({ severidad: ($event || undefined) })"
        aria-label="Filtrar por severidad"
      >
        <option value="">Severidad: Todas</option>
        <option value="CRITICA">Crítica</option>
        <option value="ALTA">Alta</option>
        <option value="MEDIA">Media</option>
        <option value="BAJA">Baja</option>
      </select>

      @if (mostrarTipoRiesgo()) {
        <select
          class="filter-bar__select"
          [ngModel]="filtros().tipoRiesgo ?? ''"
          (ngModelChange)="onCambio({ tipoRiesgo: ($event || undefined) })"
          aria-label="Filtrar por tipo de riesgo"
        >
          <option value="">Tipo de riesgo: Todos</option>
          <option value="CARPETAS">Carpetas</option>
          <option value="ADMINS">Admins</option>
          <option value="ATTACK_PATHS">Attack Paths</option>
          <option value="VIRTUAL_PATCHING">Virtual Patching</option>
          <option value="IOE">IOE</option>
          <option value="SPIDER">Spider</option>
        </select>
      }

      <button type="button" class="sk-button sk-button--secondary" (click)="limpiar.emit()">
        Limpiar
      </button>
    </div>
  `,
  styles: `
    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      align-items: center;
      margin-bottom: 16px;
    }
    .filter-bar__search {
      flex: 1 1 260px;
      min-width: 200px;
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.9rem;
      color: var(--sk-color-text);
    }
    .filter-bar__search:focus { outline: none; border-bottom-color: var(--sk-color-brand-black); }
    .filter-bar__select {
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.85rem;
      color: var(--sk-color-text);
    }
  `,
})
export class IdentityFilterBar {
  readonly filtros = input.required<FiltrosIdentidad>();
  readonly mostrarTipoRiesgo = input(true);

  readonly filtrosCambiados = output<Partial<FiltrosIdentidad>>();
  readonly limpiar = output<void>();

  protected onCambio(parcial: {
    q?: string;
    severidad?: Severidad;
    tipoRiesgo?: TipoRiesgo;
  }): void {
    this.filtrosCambiados.emit(parcial);
  }
}
