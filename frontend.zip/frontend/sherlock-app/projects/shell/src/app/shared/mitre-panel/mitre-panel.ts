import { ChangeDetectionStrategy, Component, input, signal } from '@angular/core';
import { TecnicaMitreDetectada } from '../../core/models/comun.model';
import { EmptyState } from '../empty-state/empty-state';

/**
 * Panel colapsable "MITRE ATT&CK (técnicas detectadas)" (pantallas 03-07, 09,
 * 11). Muestra el chip de cada técnica y, al expandir, el bloque de
 * evidencias (RF-018) — da trazabilidad al score/severidad que el backend ya
 * calculó, sin que el frontend reinterprete ni recalcule nada.
 */
@Component({
  selector: 'app-mitre-panel',
  imports: [EmptyState],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="mitre-panel">
      <button type="button" class="mitre-panel__toggle" (click)="expandido.set(!expandido())">
        MITRE ATT&CK (técnicas detectadas)
        <span aria-hidden="true">{{ expandido() ? '▲' : '▼' }}</span>
      </button>

      @if (expandido()) {
        @if (tecnicas().length === 0) {
          <app-empty-state
            titulo="Sin técnicas MITRE detectadas."
            descripcion="No se identificaron técnicas ATT&CK para esta identidad con las fuentes disponibles hoy."
          />
        } @else {
          <div class="mitre-panel__chips">
            @for (tecnica of tecnicas(); track tecnica.tecnicaId) {
              <span class="mitre-panel__chip">{{ tecnica.tecnicaId }} · {{ tecnica.nombreTecnica }}</span>
            }
          </div>
          <div class="mitre-panel__evidencia">
            <h4>Evidencias (por qué se tageó)</h4>
            <ul>
              @for (tecnica of tecnicas(); track tecnica.tecnicaId) {
                <li><strong>{{ tecnica.tecnicaId }}:</strong> {{ tecnica.evidencia }}</li>
              }
            </ul>
          </div>
        }
      }
    </section>
  `,
  styles: `
    .mitre-panel { border: 1px solid var(--sk-color-border); border-radius: 8px; margin: 16px 0; background: var(--sk-color-surface); }
    .mitre-panel__toggle {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: none;
      border: none;
      padding: 14px 16px;
      font-weight: 700;
      cursor: pointer;
      color: var(--sk-color-text);
      font-size: 0.9rem;
    }
    .mitre-panel__chips { display: flex; flex-wrap: wrap; gap: 8px; padding: 0 16px 12px; }
    .mitre-panel__chip {
      background: var(--sk-color-info);
      color: #fff;
      font-size: 0.75rem;
      font-weight: 600;
      padding: 4px 10px;
      border-radius: 12px;
    }
    .mitre-panel__evidencia { padding: 0 16px 16px; font-size: 0.85rem; color: var(--sk-color-text-muted); }
    .mitre-panel__evidencia h4 { margin: 0 0 6px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.03em; }
    .mitre-panel__evidencia ul { margin: 0; padding-left: 18px; }
  `,
})
export class MitrePanel {
  readonly tecnicas = input.required<TecnicaMitreDetectada[]>();
  protected readonly expandido = signal(false);
}
