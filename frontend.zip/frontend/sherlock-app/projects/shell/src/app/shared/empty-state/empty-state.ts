import { ChangeDetectionStrategy, Component, input } from '@angular/core';

/**
 * Estado vacío estandarizado transversal (HU-17). El mismo componente visual
 * se reutiliza en todos los módulos (Servers/Users/Groups y sus
 * sub-pestañas) y en la búsqueda global (HU-11 CA3) — el texto es
 * configurable por `@Input()` sin duplicar el componente (HU-17 CA2), tal
 * como se ve en la pantalla 12 (`jpg/12-estado-vacio-modulo.jpg`).
 */
@Component({
  selector: 'app-empty-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="empty-state">
      <div class="empty-state__icon" aria-hidden="true">{{ icono() }}</div>
      <p class="empty-state__titulo">{{ titulo() }}</p>
      @if (descripcion()) {
        <p class="empty-state__descripcion">{{ descripcion() }}</p>
      }
    </div>
  `,
  styles: `
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 48px 24px;
      text-align: center;
      color: var(--sk-color-text-muted);
    }
    .empty-state__icon {
      font-size: 2rem;
      line-height: 1;
      opacity: 0.6;
    }
    .empty-state__titulo {
      margin: 0;
      font-weight: 700;
      color: var(--sk-color-text);
    }
    .empty-state__descripcion {
      margin: 0;
      font-size: 0.85rem;
      max-width: 420px;
    }
  `,
})
export class EmptyState {
  /** Texto principal, ej. "Sin resultados." (pantalla 12) o el mensaje de
   * HU-16 CA2 para Attack Paths ("depende de una fuente aún no habilitada"). */
  readonly titulo = input('Sin resultados.');
  readonly descripcion = input<string | undefined>(undefined);
  readonly icono = input('🔍');
}
