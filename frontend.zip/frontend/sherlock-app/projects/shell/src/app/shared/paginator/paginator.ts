import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';

/**
 * Paginador prev/next + página actual (patrón real `Molecules/Paginator` del
 * Design System Caribe/BDS, ver `figma/README-importar-a-figma.md`). Usado en
 * los 3 listados (pantallas 02, 08, 10: "Mostrando 10 de 40 servidores").
 */
@Component({
  selector: 'app-paginator',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="paginator">
      <span class="paginator__resumen">
        Mostrando {{ inicio() }}–{{ fin() }} de {{ total() }}
      </span>
      <div class="paginator__controles">
        <button type="button" class="sk-button sk-button--tertiary" [disabled]="page() === 0" (click)="cambiarPagina.emit(page() - 1)">
          ‹ Anterior
        </button>
        <span class="paginator__pagina">Página {{ page() + 1 }} de {{ totalPaginas() }}</span>
        <button
          type="button"
          class="sk-button sk-button--tertiary"
          [disabled]="page() + 1 >= totalPaginas()"
          (click)="cambiarPagina.emit(page() + 1)"
        >
          Siguiente ›
        </button>
      </div>
    </div>
  `,
  styles: `
    .paginator {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      justify-content: space-between;
      align-items: center;
      margin-top: 16px;
      font-size: 0.85rem;
      color: var(--sk-color-text-muted);
    }
    .paginator__controles { display: flex; align-items: center; gap: 10px; }
  `,
})
export class Paginator {
  readonly total = input.required<number>();
  readonly page = input.required<number>();
  readonly size = input.required<number>();

  readonly cambiarPagina = output<number>();

  protected readonly totalPaginas = computed(() => Math.max(1, Math.ceil(this.total() / this.size())));
  protected readonly inicio = computed(() => (this.total() === 0 ? 0 : this.page() * this.size() + 1));
  protected readonly fin = computed(() => Math.min(this.total(), (this.page() + 1) * this.size()));
}
