import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { Severidad } from '../../core/models/comun.model';

const ETIQUETA: Record<Severidad, string> = {
  CRITICA: 'CRIT',
  ALTA: 'HIGH',
  MEDIA: 'MED',
  BAJA: 'LOW',
};

const CLASE: Record<Severidad, string> = {
  CRITICA: 'sk-badge--critica',
  ALTA: 'sk-badge--alta',
  MEDIA: 'sk-badge--media',
  BAJA: 'sk-badge--baja',
};

/**
 * Badge de severidad con los 4 colores reales del sistema Caribe/BDS
 * (`.bc-badge-red|orange|yellow|green`, ver
 * `resources/ux/ui/figma/README-importar-a-figma.md`): Crítica `#e20201`,
 * Alta `#ff7f41`, Media `#fdda24`, Baja `#00c389`. Los tokens de color viven
 * en `styles.scss` (variables `--sk-severidad-*`).
 */
@Component({
  selector: 'app-severity-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="sk-badge" [class]="clase()">{{ etiqueta() }}</span>`,
  styles: `
    .sk-badge {
      display: inline-block;
      font-size: 0.7rem;
      font-weight: 700;
      letter-spacing: 0.03em;
      padding: 2px 10px;
      border-radius: 10px;
      color: #fff;
      text-transform: uppercase;
    }
    .sk-badge--critica { background: var(--sk-severidad-critica); }
    .sk-badge--alta { background: var(--sk-severidad-alta); }
    .sk-badge--media { background: var(--sk-severidad-media); color: var(--sk-color-brand-black); }
    .sk-badge--baja { background: var(--sk-severidad-baja); }
  `,
})
export class SeverityBadge {
  readonly severidad = input.required<Severidad>();

  protected readonly etiqueta = computed(() => ETIQUETA[this.severidad()]);
  protected readonly clase = computed(() => CLASE[this.severidad()]);
}
