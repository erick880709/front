import { initFederation } from '@angular-architects/native-federation';

initFederation(
  {
    // El remoto "dashboard" sirve en el puerto 4201 (ver angular.json ->
    // projects.dashboard.architect.serve-original.options.port). Este mapeo
    // es la prueba de concepto de Module Federation exigida por TT-13/ADR-008:
    // en este ciclo el shell SIGUE cargando el remoto dashboard en runtime,
    // aunque ambos se compilen y desplieguen juntos como un único bundle.
    dashboard: 'http://localhost:4201/remoteEntry.json',
  },
  {
    hostRemoteEntry: { url: './remoteEntry.json' },
  },
)
  .catch((err) => console.error(err))
  .then((_) => import('./bootstrap'))
  .catch((err) => console.error(err));
