/** Ver `projects/shell/src/environments/environment.ts` para el detalle de
 * por qué `apiBaseUrl` es una ruta relativa. El remoto `dashboard` es
 * independiente y buildable por sí solo (requisito de Module Federation):
 * declara su propia configuración de entorno en vez de depender de la del
 * shell. */
export const environment = {
  production: false,
  apiBaseUrl: '/api',
};
