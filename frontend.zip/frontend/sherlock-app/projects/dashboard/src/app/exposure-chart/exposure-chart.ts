import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  input,
  output,
  viewChild,
} from '@angular/core';
import { Chart, type ChartConfiguration } from 'chart.js/auto';
import { TipoRiesgo } from '../core/dashboard.model';

const ORDEN: TipoRiesgo[] = ['CARPETAS', 'ADMINS', 'ATTACK_PATHS', 'VIRTUAL_PATCHING', 'IOE'];
const ETIQUETAS: Record<TipoRiesgo, string> = {
  CARPETAS: 'Carpetas',
  ADMINS: 'Admins',
  ATTACK_PATHS: 'Paths',
  VIRTUAL_PATCHING: 'VP',
  IOE: 'IOE',
  SPIDER: 'Spider',
};
/** Misma paleta categórica real `--sk-data-00..07` (`.bc-bg-data-00..08` en el
 * Storybook Caribe, ver `resources/ux/ui/especificacion-componentes-storybook.html`
 * y `dashboard/src/styles.scss`) — hardcodeada aquí en vez de leída desde CSS
 * porque Chart.js necesita el string de color directamente, igual que ya hace
 * `severity-chart.ts` con su propia paleta de severidad. */
const COLORES: Record<TipoRiesgo, string> = {
  CARPETAS: '#9063cd', // --sk-data-06
  ADMINS: '#1ea1e4', // --sk-data-04
  ATTACK_PATHS: '#ed7620', // --sk-data-01
  VIRTUAL_PATCHING: '#00a574', // --sk-data-03
  IOE: '#cd3f3f', // --sk-data-00
  SPIDER: '#888888', // --sk-data-07
};

/**
 * Gráfico de barras "Exposición por Brecha" (pantalla 01, ver
 * `documento-funcional-tecnico-pantallas.html` §01 y el mockup
 * `01-dashboard-principal-servers.jpg`). Sigue el mismo patrón que
 * `severity-chart.ts` (Chart.js, `@Output()` de selección delegado al padre).
 */
@Component({
  selector: 'app-exposure-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="exposure-chart sk-card">
      <h3 class="sk-heading">Exposición por brecha</h3>
      <canvas #canvas role="img" aria-label="Gráfico de barras de exposición por brecha"></canvas>
    </div>
  `,
  styles: `
    .exposure-chart canvas { max-height: 240px; }
  `,
})
export class ExposureChart implements AfterViewInit, OnChanges, OnDestroy {
  readonly exposicion = input.required<Record<string, number>>();
  readonly brechaSeleccionada = output<TipoRiesgo>();

  private readonly canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>('canvas');
  private chart?: Chart;

  ngAfterViewInit(): void {
    this.crearOActualizarChart();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['exposicion'] && this.chart) {
      this.crearOActualizarChart();
    }
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private crearOActualizarChart(): void {
    const datos = this.exposicion();
    const config: ChartConfiguration<'bar'> = {
      type: 'bar',
      data: {
        labels: ORDEN.map((k) => ETIQUETAS[k]),
        datasets: [
          {
            data: ORDEN.map((k) => datos[k] ?? 0),
            backgroundColor: ORDEN.map((k) => COLORES[k]),
            borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
        onClick: (_evento, elementos) => {
          if (elementos.length > 0) {
            const indice = elementos[0].index;
            this.brechaSeleccionada.emit(ORDEN[indice]);
          }
        },
      },
    };

    if (this.chart) {
      this.chart.data = config.data;
      this.chart.update();
      return;
    }

    this.chart = new Chart(this.canvasRef().nativeElement, config);
  }
}
