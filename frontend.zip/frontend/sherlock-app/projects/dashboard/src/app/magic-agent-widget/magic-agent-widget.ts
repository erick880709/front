import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

/**
 * Widget embebido del "Sherlock Magic Agent" en el propio dashboard (pantalla
 * 01, HU-23), a diferencia de la tarjeta-enlace anterior: el mockup
 * (`01-dashboard-principal-servers.jpg`) muestra un input de chat inline, no
 * solo un acceso rápido.
 *
 * Este remoto (`dashboard`) no tiene su propio `MagicAgentService`/endpoint de
 * IA conectado — `dashboard-api.service.ts` solo expone `dashboard-summary` y
 * `sources/status` — y la implementación única del chat real (rule-based,
 * `POST /api/chat`) vive en `shell/src/app/features/magic-agent` (ver
 * `magic-agent-chat.ts`), que no se importa cross-proyecto a propósito. Por
 * eso este widget muestra el input pedido por el mockup pero responde con un
 * mensaje de fallback + enlace a `/asistente` (compartido como singleton por
 * Module Federation) en vez de duplicar la lógica de matching del chat.
 */
@Component({
  selector: 'app-magic-agent-widget',
  imports: [FormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="magic-agent-widget sk-card">
      <header class="magic-agent-widget__header">
        <h3 class="sk-heading">Sherlock Magic Agent</h3>
        <span class="magic-agent-widget__badge">Rule-Based</span>
      </header>
      <p class="magic-agent-widget__hint">Consulta por servidores, usuarios, grupos o alertas.</p>

      @if (mensaje(); as m) {
        <p class="magic-agent-widget__respuesta">
          {{ m }}
          <a routerLink="/asistente">Ir al asistente completo →</a>
        </p>
      }

      <form class="magic-agent-widget__form" (submit)="preguntar($event)">
        <input
          name="pregunta"
          type="text"
          [(ngModel)]="pregunta"
          placeholder="Ej: riesgo de SRV-WEB-01"
          aria-label="Pregunta al Sherlock Magic Agent"
        />
        <button type="submit" class="sk-button sk-button--primary" [disabled]="!pregunta.trim()">
          Preguntar
        </button>
      </form>
    </section>
  `,
  styles: `
    .magic-agent-widget { display: flex; flex-direction: column; gap: 10px; }
    .magic-agent-widget__header { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .magic-agent-widget__badge {
      font-size: 0.65rem;
      font-weight: 700;
      text-transform: uppercase;
      color: var(--sk-color-text-muted);
      background: var(--sk-color-surface-alt);
      padding: 3px 8px;
      border-radius: 10px;
    }
    .magic-agent-widget__hint { margin: 0; font-size: 0.8rem; color: var(--sk-color-text-muted); }
    .magic-agent-widget__respuesta {
      margin: 0;
      font-size: 0.8rem;
      background: var(--sk-color-surface-alt);
      border-radius: 8px;
      padding: 8px 10px;
    }
    .magic-agent-widget__respuesta a { color: var(--sk-color-brand-black); font-weight: 700; }
    .magic-agent-widget__form { display: flex; gap: 8px; }
    .magic-agent-widget__form input {
      flex: 1;
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.85rem;
      color: var(--sk-color-text);
    }
    .magic-agent-widget__form input:focus { outline: none; border-bottom-color: var(--sk-color-brand-black); }
  `,
})
export class MagicAgentWidget {
  protected pregunta = '';
  protected readonly mensaje = signal<string | null>(null);

  protected preguntar(evento: SubmitEvent): void {
    evento.preventDefault();
    if (!this.pregunta.trim()) return;

    this.mensaje.set('Esta función está disponible en el asistente completo.');
    this.pregunta = '';
  }
}
