/**
 * Modelos mínimos del remoto `dashboard`. Se declaran de forma independiente
 * a los de `projects/shell/src/app/core/models` a propósito: cada remoto de
 * Module Federation debe poder compilarse y desplegarse por separado, sin
 * depender de las carpetas internas de otro proyecto del workspace. En una
 * evolución futura con más remotos, este contrato compartido (DashboardResumen,
 * EstadoFuente, Severidad) se extraería a una librería Angular publicada
 * (`projects/sherlock-domain` o un paquete npm interno) — se documenta como
 * decisión pendiente en el README del workspace, no se resuelve en este ciclo
 * porque solo existe un remoto de referencia.
 */
export type Severidad = 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA';

/** Tipo de riesgo / fuente de exposición (para el filtro combinable de la
 * pantalla 01 y para las claves de `exposicionPorBrecha`). Copiado de
 * `projects/shell/src/app/core/models/comun.model.ts` (mismo shape, sin
 * importar cross-proyecto — ver comentario de cabecera de este archivo). */
export type TipoRiesgo =
  | 'CARPETAS'
  | 'ADMINS'
  | 'ATTACK_PATHS'
  | 'VIRTUAL_PATCHING'
  | 'IOE'
  | 'SPIDER';

export interface DashboardResumen {
  riesgoGlobalPorcentaje: number;
  nivelRiesgoGlobal: string;
  distribucionSeveridad: Record<Severidad, number>;
  /** Gráfica "Exposición por Brecha" (pantalla 01). Copiado tal cual de
   * `shell/src/app/core/models/dashboard.model.ts` para mantener consistencia
   * de forma entre los dos proyectos independientes. */
  exposicionPorBrecha: Record<string, number>;
  /** Gráfica "MITRE Técnicas más frecuentes" (pantalla 01). */
  tecnicasMitreFrecuentes: { tecnicaId: string; nombreTecnica: string; conteo: number }[];
}

export interface EstadoFuente {
  fuenteId: string;
  nombre: string;
  ultimaSincronizacion: string | null;
  estado: 'OK' | 'DESACTUALIZADA' | 'SIN_DATOS' | 'ERROR';
}

/** Filtros combinables de la barra superior del dashboard (búsqueda + severidad
 * + tipo de riesgo). Este remoto no carga un listado de identidades propio
 * (solo datos agregados de `dashboard-summary`/`sources/status`), así que el
 * filtrado se resuelve client-side sobre las 3 gráficas ya cargadas — ver
 * `app.ts` (`distribucionFiltrada`/`exposicionFiltrada`/`tecnicasFiltradas`). */
export interface FiltrosDashboard {
  q?: string;
  severidad?: Severidad;
  tipoRiesgo?: TipoRiesgo;
}
