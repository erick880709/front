import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { DashboardResumen, EstadoFuente } from './dashboard.model';

/** Cliente HTTP del remoto `dashboard` — mismos endpoints documentados en
 * `resources/ux/ui/documento-funcional-tecnico-pantallas.html` (pantalla 01):
 * `GET /api/servers/dashboard-summary` y `GET /api/sources/status`. */
@Injectable({ providedIn: 'root' })
export class DashboardApiService {
  private readonly http = inject(HttpClient);

  obtenerResumen(): Observable<DashboardResumen> {
    return this.http.get<DashboardResumen>(`${environment.apiBaseUrl}/servers/dashboard-summary`);
  }

  obtenerEstadoFuentes(): Observable<EstadoFuente[]> {
    return this.http.get<EstadoFuente[]>(`${environment.apiBaseUrl}/sources/status`);
  }

  /** Botón "Recargar Excel" (pantalla 01, RF-023). Mismo endpoint documentado
   * en `documento-funcional-tecnico-pantallas.html` (`POST /api/sources/reload`)
   * que ya consume `FuentesService.recargarFuentes()` en el shell — se declara
   * aquí de forma independiente (mismo path relativo, no el mismo código) para
   * que este remoto siga siendo desplegable por separado. */
  recargarFuentes(): Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/sources/reload`, {});
  }
}
