import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  input,
  viewChild,
} from '@angular/core';
import { Chart, type ChartConfiguration } from 'chart.js/auto';

export interface TecnicaMitreFrecuente {
  tecnicaId: string;
  nombreTecnica: string;
  conteo: number;
}

/** Misma paleta categórica real `--sk-data-00..07` que usa `exposure-chart.ts`
 * (`.bc-bg-data-00..08`), en el mismo orden visual que el mockup
 * `01-dashboard-principal-servers.jpg` (azul oscuro, morado, celeste, naranja,
 * rojo, verde) — se cicla si llegan más de 8 técnicas. */
const COLORES = ['#1e4dc4', '#9063cd', '#1ea1e4', '#ed7620', '#cd3f3f', '#00a574', '#fdda24', '#888888'];

/**
 * Gráfico de barras "MITRE Técnicas más frecuentes" (pantalla 01, ver
 * `documento-funcional-tecnico-pantallas.html` §01). Sigue el mismo patrón
 * que `severity-chart.ts`/`exposure-chart.ts` (Chart.js). No emite selección:
 * a diferencia de Severidad/Exposición por Brecha, no hay una ruta de listado
 * propia para "técnica MITRE" en el backlog analizado (ADR-005 solo reserva
 * el contrato de rutas de ataque) — este gráfico es de solo lectura.
 */
@Component({
  selector: 'app-mitre-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mitre-chart sk-card">
      <h3 class="sk-heading">MITRE técnicas más frecuentes</h3>
      <canvas #canvas role="img" aria-label="Gráfico de barras de técnicas MITRE más frecuentes"></canvas>
    </div>
  `,
  styles: `
    .mitre-chart canvas { max-height: 260px; }
  `,
})
export class MitreChart implements AfterViewInit, OnChanges, OnDestroy {
  readonly tecnicas = input.required<TecnicaMitreFrecuente[]>();

  private readonly canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>('canvas');
  private chart?: Chart;

  ngAfterViewInit(): void {
    this.crearOActualizarChart();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['tecnicas'] && this.chart) {
      this.crearOActualizarChart();
    }
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private crearOActualizarChart(): void {
    const tecnicas = this.tecnicas();
    const config: ChartConfiguration<'bar'> = {
      type: 'bar',
      data: {
        labels: tecnicas.map((t) => t.tecnicaId),
        datasets: [
          {
            data: tecnicas.map((t) => t.conteo),
            backgroundColor: tecnicas.map((_, i) => COLORES[i % COLORES.length]),
            borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              title: (items) => tecnicas[items[0]?.dataIndex ?? 0]?.nombreTecnica ?? '',
            },
          },
        },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    };

    if (this.chart) {
      this.chart.data = config.data;
      this.chart.update();
      return;
    }

    this.chart = new Chart(this.canvasRef().nativeElement, config);
  }
}
