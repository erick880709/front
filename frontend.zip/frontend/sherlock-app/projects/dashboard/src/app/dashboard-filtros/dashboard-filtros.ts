import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FiltrosDashboard, Severidad, TipoRiesgo } from '../core/dashboard.model';

/**
 * Buscador + filtro de severidad + filtro de tipo de riesgo de la pantalla 01
 * (ver `documento-funcional-tecnico-pantallas.html` §01 y el mockup
 * `01-dashboard-principal-servers.jpg`). Equivalente propio de este remoto a
 * `shell/src/app/shared/identity-filter-bar/identity-filter-bar.ts` (mismo
 * estilo visual: `.bc-input`/borde inferior 2px según
 * `especificacion-componentes-storybook.html`) — no se importa cross-proyecto
 * porque `dashboard` debe compilarse y desplegarse de forma independiente.
 *
 * Es un componente puro de presentación: no filtra nada por sí mismo, emite
 * los cambios para que `App` (`app.ts`) los aplique client-side sobre las 3
 * gráficas ya cargadas (este remoto no tiene un listado de identidades propio
 * contra el cual pedir un filtrado real al backend).
 */
@Component({
  selector: 'app-dashboard-filtros',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="dashboard-filtros">
      <input
        class="dashboard-filtros__input"
        type="search"
        [ngModel]="filtros().q ?? ''"
        (ngModelChange)="onCambio({ q: $event || undefined })"
        placeholder="Nombre del servidor, IP, owner..."
        aria-label="Búsqueda en el dashboard"
      />

      <select
        class="dashboard-filtros__select"
        [ngModel]="filtros().severidad ?? ''"
        (ngModelChange)="onCambio({ severidad: $event || undefined })"
        aria-label="Filtrar por severidad"
      >
        <option value="">Severidad: Todas</option>
        <option value="CRITICA">Crítica</option>
        <option value="ALTA">Alta</option>
        <option value="MEDIA">Media</option>
        <option value="BAJA">Baja</option>
      </select>

      <select
        class="dashboard-filtros__select"
        [ngModel]="filtros().tipoRiesgo ?? ''"
        (ngModelChange)="onCambio({ tipoRiesgo: $event || undefined })"
        aria-label="Filtrar por tipo de riesgo"
      >
        <option value="">Tipo de riesgo: Todos</option>
        <option value="CARPETAS">Carpetas</option>
        <option value="ADMINS">Admins</option>
        <option value="ATTACK_PATHS">Attack Paths</option>
        <option value="VIRTUAL_PATCHING">Virtual Patching</option>
        <option value="IOE">IOE</option>
        <option value="SPIDER">Spider</option>
      </select>

      <button type="button" class="sk-button sk-button--tertiary" (click)="limpiar.emit()">Limpiar</button>
    </div>
  `,
  styles: `
    .dashboard-filtros {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      align-items: center;
    }
    .dashboard-filtros__input {
      flex: 1 1 260px;
      min-width: 200px;
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.9rem;
      color: var(--sk-color-text);
    }
    .dashboard-filtros__input:focus { outline: none; border-bottom-color: var(--sk-color-brand-black); }
    .dashboard-filtros__select {
      border: none;
      border-bottom: 2px solid var(--sk-color-border);
      background: transparent;
      padding: 8px 4px;
      font-size: 0.85rem;
      color: var(--sk-color-text);
    }
  `,
})
export class DashboardFiltros {
  readonly filtros = input.required<FiltrosDashboard>();
  readonly filtrosCambiados = output<Partial<FiltrosDashboard>>();
  readonly limpiar = output<void>();

  protected onCambio(parcial: { q?: string; severidad?: Severidad; tipoRiesgo?: TipoRiesgo }): void {
    this.filtrosCambiados.emit(parcial);
  }
}
