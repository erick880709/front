import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { routes } from './app.routes';

/**
 * Configuración usada únicamente cuando `dashboard` se sirve/compila de
 * forma standalone (`ng serve dashboard`, útil en desarrollo aislado del
 * remoto). Cuando el shell lo carga vía Module Federation
 * (`loadRemoteModule('dashboard', './Component')`), el componente `App` se
 * instancia dentro del árbol de inyección del shell y usa los providers del
 * host (`projects/shell/src/app/app.config.ts`) — este archivo no se
 * ejecuta en ese flujo.
 */
export const appConfig: ApplicationConfig = {
  providers: [provideBrowserGlobalErrorListeners(), provideRouter(routes), provideHttpClient()],
};
