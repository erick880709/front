import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  input,
  output,
  viewChild,
} from '@angular/core';
import { Chart, type ChartConfiguration } from 'chart.js/auto';
import { Severidad } from '../core/dashboard.model';

const ORDEN: Severidad[] = ['CRITICA', 'ALTA', 'MEDIA', 'BAJA'];
const ETIQUETAS: Record<Severidad, string> = { CRITICA: 'CRIT', ALTA: 'HIGH', MEDIA: 'MED', BAJA: 'LOW' };
const COLORES: Record<Severidad, string> = {
  CRITICA: '#e20201',
  ALTA: '#ff7f41',
  MEDIA: '#fdda24',
  BAJA: '#00c389',
};

/**
 * Gráfico de barras de distribución de severidad (HU-08).
 *
 * Librería elegida: **Chart.js**, la misma que ya validó el prototipo
 * (`context/codigo/Part2/web/new.html`, ver `EXPLICACION_CODIGO.md` §4) — no
 * hay un componente de gráficos nativo en el catálogo real de 71 componentes
 * de Caribe/BDS auditado en `resources/ux/ui/figma/README-importar-a-figma.md`
 * (el storybook real no incluye ningún organismo de tipo "Chart"), así que no
 * se está descartando una alternativa del propio sistema de diseño: Chart.js
 * es la única opción evaluada con un caso de uso real en este ciclo, y ya
 * viene con antecedente de uso validado por el banco.
 *
 * CA2 (clic en una barra filtra el listado) se expone como `@Output()` — este
 * componente no navega por sí mismo, delega en quien lo use (ver
 * `dashboard/src/app/app.ts`).
 */
@Component({
  selector: 'app-severity-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="severity-chart sk-card">
      <h3 class="sk-heading">Distribución de severidad</h3>
      <canvas #canvas role="img" aria-label="Gráfico de barras de distribución de severidad"></canvas>
    </div>
  `,
  styles: `
    .severity-chart canvas { max-height: 240px; }
  `,
})
export class SeverityChart implements AfterViewInit, OnChanges, OnDestroy {
  readonly distribucion = input.required<Record<Severidad, number>>();
  readonly severidadSeleccionada = output<Severidad>();

  private readonly canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>('canvas');
  private chart?: Chart;

  ngAfterViewInit(): void {
    this.crearOActualizarChart();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['distribucion'] && this.chart) {
      this.crearOActualizarChart();
    }
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private crearOActualizarChart(): void {
    const datos = this.distribucion();
    const config: ChartConfiguration<'bar'> = {
      type: 'bar',
      data: {
        labels: ORDEN.map((s) => ETIQUETAS[s]),
        datasets: [
          {
            data: ORDEN.map((s) => datos[s] ?? 0),
            backgroundColor: ORDEN.map((s) => COLORES[s]),
            borderRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
        onClick: (_evento, elementos) => {
          if (elementos.length > 0) {
            const indice = elementos[0].index;
            this.severidadSeleccionada.emit(ORDEN[indice]);
          }
        },
      },
    };

    if (this.chart) {
      this.chart.data = config.data;
      this.chart.update();
      return;
    }

    this.chart = new Chart(this.canvasRef().nativeElement, config);
  }
}
