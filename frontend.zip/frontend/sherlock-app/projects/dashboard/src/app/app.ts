import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { Subject, catchError, finalize, merge, of, switchMap, timer } from 'rxjs';
import { DashboardApiService } from './core/dashboard-api.service';
import { DashboardResumen, EstadoFuente, FiltrosDashboard, Severidad, TipoRiesgo } from './core/dashboard.model';
import { DashboardFiltros } from './dashboard-filtros/dashboard-filtros';
import { ExposureChart } from './exposure-chart/exposure-chart';
import { MagicAgentWidget } from './magic-agent-widget/magic-agent-widget';
import { MitreChart } from './mitre-chart/mitre-chart';
import { RiskIndicator } from './risk-indicator/risk-indicator';
import { SeverityChart } from './severity-chart/severity-chart';
import { SourcesStatus } from './sources-status/sources-status';

const INTERVALO_ACTUALIZACION_MS = 60_000;
const ORDEN_SEVERIDAD: Severidad[] = ['CRITICA', 'ALTA', 'MEDIA', 'BAJA'];

/**
 * Componente raíz del remoto Module Federation `dashboard` (expuesto como
 * `./Component`, ver `federation.config.mjs`). Compone el layout completo de
 * la pantalla 01 exigido por TT-13 (HU-07 + HU-08 + panel de fuentes) y
 * cerrado por la auditoría UX posterior (RF-013/RF-020/RF-022/RF-023):
 *
 * - HU-07 (Estado de Riesgo Global): CA2 se resuelve con un `timer` que
 *   vuelve a pedir el resumen cada 60s sin recargar la página — cuando el
 *   backend real esté conectado, este mismo patrón podría reemplazarse por
 *   un stream push (SSE/WebSocket) sin tocar `RiskIndicator`.
 * - HU-08 (3 gráficas: Severidad / Exposición por Brecha / MITRE Técnicas):
 *   al hacer clic en una barra de Severidad o Exposición por Brecha, navega
 *   al listado de servidores filtrado (CA2) usando el mismo `Router` del
 *   shell (compartido como singleton por Module Federation, ver
 *   `federation.config.mjs` → `shareAll`). El gráfico MITRE es de solo
 *   lectura (no hay ruta de listado propia por técnica en el backlog).
 * - RF-013 (búsqueda + filtro de severidad + filtro de tipo de riesgo): este
 *   remoto no carga un listado de identidades propio, así que el filtrado se
 *   resuelve client-side sobre las 3 gráficas ya cargadas (ver los signals
 *   `distribucionFiltrada`/`exposicionFiltrada`/`tecnicasFiltradas`) — es un
 *   supuesto explícito, documentado también en `dashboard.model.ts`
 *   (`FiltrosDashboard`).
 * - RF-020 (exportación JSON/CSV/PDF): sin un endpoint de export propio de
 *   este remoto (el `POST /api/servers/export` documentado en
 *   `documento-funcional-tecnico-pantallas.html` exporta el listado de
 *   servidores del módulo Servidores, que este dashboard no carga), JSON/CSV
 *   se generan client-side (Blob) a partir del resumen ya cargado, y PDF usa
 *   `window.print()` con estilos de impresión (`@media print` más abajo) — no
 *   hay librería de PDF instalada en el proyecto (`package.json` del
 *   workspace no la tiene) y no se agregó una nueva sin avisar.
 * - RF-023 (Recargar Excel): `DashboardApiService.recargarFuentes()` golpea
 *   el mismo endpoint (`POST /api/sources/reload`) que ya usa
 *   `FuentesService.recargarFuentes()` en el shell.
 * - HU-23 (Sherlock Magic Agent): se representa aquí como un widget de chat
 *   embebido (`MagicAgentWidget`) con fallback a `/asistente`, en vez de
 *   duplicar el chat completo (rule-based) que vive en
 *   `projects/shell/src/app/features/magic-agent` — se evita así tener dos
 *   copias del mismo componente en dos proyectos distintos del workspace.
 */
@Component({
  selector: 'app-root',
  imports: [
    DashboardFiltros,
    ExposureChart,
    MagicAgentWidget,
    MitreChart,
    RiskIndicator,
    SeverityChart,
    SourcesStatus,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="dashboard">
      <h2 class="sk-heading">Dashboard</h2>

      <div class="dashboard__toolbar sk-card">
        <app-dashboard-filtros
          [filtros]="filtros()"
          (filtrosCambiados)="onFiltrosCambiados($event)"
          (limpiar)="filtros.set({})"
        />
        <div class="dashboard__acciones">
          <button type="button" class="sk-button sk-button--secondary" (click)="exportarJson()">
            Exportar JSON (vista)
          </button>
          <button type="button" class="sk-button sk-button--secondary" (click)="exportarCsv()">
            Exportar CSV (vista)
          </button>
          <button type="button" class="sk-button sk-button--secondary" (click)="exportarPdf()">
            Exportar PDF (resumen)
          </button>
          <button
            type="button"
            class="sk-button sk-button--tertiary"
            [disabled]="recargando()"
            (click)="recargarExcel()"
          >
            {{ recargando() ? 'Recargando…' : 'Recargar Excel' }}
          </button>
        </div>
      </div>

      @if (resumen(); as r) {
        <app-risk-indicator [porcentaje]="r.riesgoGlobalPorcentaje" [nivel]="r.nivelRiesgoGlobal" />

        <div class="dashboard__grid">
          <app-severity-chart [distribucion]="distribucionFiltrada()!" (severidadSeleccionada)="irAServidoresFiltrados($event)" />
          <app-exposure-chart [exposicion]="exposicionFiltrada()!" (brechaSeleccionada)="irAServidoresPorTipoRiesgo($event)" />
        </div>

        <app-mitre-chart [tecnicas]="tecnicasFiltradas()" />
      } @else if (cargando()) {
        <p>Cargando resumen…</p>
      }

      <div class="dashboard__bottom">
        <app-sources-status [fuentes]="fuentes()" />
        <app-magic-agent-widget />
      </div>
    </div>
  `,
  styles: `
    .dashboard { display: flex; flex-direction: column; gap: 20px; }
    .dashboard__toolbar { display: flex; flex-direction: column; gap: 12px; }
    .dashboard__acciones { display: flex; flex-wrap: wrap; gap: 10px; }
    .dashboard__grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
    .dashboard__bottom { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px; }

    /* RF-020 "Exportar PDF (resumen)": sin endpoint de export PDF propio de
       este remoto, se usa window.print() como export client-side — estos
       estilos ocultan los controles interactivos que no aportan a un PDF de
       resumen impreso. */
    @media print {
      .dashboard__toolbar,
      app-magic-agent-widget {
        display: none;
      }
    }
  `,
})
export class App {
  private readonly api = inject(DashboardApiService);
  private readonly router = inject(Router);
  private readonly recargaManual$ = new Subject<void>();

  protected readonly cargando = signal(true);
  protected readonly recargando = signal(false);
  protected readonly filtros = signal<FiltrosDashboard>({});

  protected readonly resumen = toSignal(
    timer(0, INTERVALO_ACTUALIZACION_MS).pipe(
      switchMap(() => {
        this.cargando.set(true);
        return this.api.obtenerResumen().pipe(
          catchError(() => of(null)),
          finalize(() => this.cargando.set(false)),
        );
      }),
    ),
    { initialValue: null as DashboardResumen | null },
  );

  protected readonly fuentes = toSignal(
    merge(timer(0, INTERVALO_ACTUALIZACION_MS), this.recargaManual$).pipe(
      switchMap(() => this.api.obtenerEstadoFuentes().pipe(catchError(() => of([] as EstadoFuente[])))),
    ),
    { initialValue: [] as EstadoFuente[] },
  );

  /** CA de RF-013: filtro de severidad aplicado client-side sobre la
   * distribución ya cargada (deja en 0 las severidades no seleccionadas en
   * vez de recalcular contra el backend, que no expone este dashboard un
   * listado de identidades filtrable). */
  protected readonly distribucionFiltrada = computed(() => {
    const r = this.resumen();
    if (!r) return null;
    const severidad = this.filtros().severidad;
    if (!severidad) return r.distribucionSeveridad;
    return ORDEN_SEVERIDAD.reduce(
      (acc, s) => ({ ...acc, [s]: s === severidad ? (r.distribucionSeveridad[s] ?? 0) : 0 }),
      {} as Record<Severidad, number>,
    );
  });

  /** CA de RF-013: filtro de tipo de riesgo + búsqueda de texto, aplicados
   * client-side sobre las claves ya agregadas de "Exposición por Brecha"
   * (no hay identidades individuales cargadas en este remoto para buscar). */
  protected readonly exposicionFiltrada = computed(() => {
    const r = this.resumen();
    if (!r) return null;
    const { tipoRiesgo, q } = this.filtros();
    const texto = q?.trim().toLowerCase();
    return Object.fromEntries(
      Object.entries(r.exposicionPorBrecha ?? {}).filter(([clave]) => {
        if (tipoRiesgo && clave !== tipoRiesgo) return false;
        if (texto && !clave.toLowerCase().includes(texto)) return false;
        return true;
      }),
    );
  });

  /** CA de RF-013: búsqueda de texto aplicada client-side sobre id/nombre de
   * técnica MITRE ya cargados. */
  protected readonly tecnicasFiltradas = computed(() => {
    const r = this.resumen();
    if (!r) return [];
    const texto = this.filtros().q?.trim().toLowerCase();
    if (!texto) return r.tecnicasMitreFrecuentes ?? [];
    return (r.tecnicasMitreFrecuentes ?? []).filter(
      (t) => t.tecnicaId.toLowerCase().includes(texto) || t.nombreTecnica.toLowerCase().includes(texto),
    );
  });

  protected onFiltrosCambiados(parcial: Partial<FiltrosDashboard>): void {
    this.filtros.update((actual) => ({ ...actual, ...parcial }));
  }

  protected irAServidoresFiltrados(severidad: Severidad): void {
    this.router.navigate(['/servidores'], { queryParams: { severidad } });
  }

  protected irAServidoresPorTipoRiesgo(tipoRiesgo: TipoRiesgo): void {
    this.router.navigate(['/servidores'], { queryParams: { tipoRiesgo } });
  }

  protected recargarExcel(): void {
    this.recargando.set(true);
    this.api
      .recargarFuentes()
      .pipe(
        catchError(() => of(void 0)),
        finalize(() => this.recargando.set(false)),
      )
      .subscribe(() => this.recargaManual$.next());
  }

  protected exportarJson(): void {
    const r = this.resumen();
    if (!r) return;
    const contenido = JSON.stringify({ resumen: r, fuentes: this.fuentes() }, null, 2);
    this.descargar(new Blob([contenido], { type: 'application/json' }), 'sherlock-dashboard.json');
  }

  protected exportarCsv(): void {
    const r = this.resumen();
    if (!r) return;
    const filas = [
      ['categoria', 'valor'],
      ...ORDEN_SEVERIDAD.map((s) => [`severidad:${s}`, String(r.distribucionSeveridad[s] ?? 0)]),
      ...Object.entries(r.exposicionPorBrecha ?? {}).map(([k, v]) => [`brecha:${k}`, String(v)]),
      ...(r.tecnicasMitreFrecuentes ?? []).map((t) => [`mitre:${t.tecnicaId}`, String(t.conteo)]),
    ];
    const csv = filas.map((fila) => fila.join(',')).join('\n');
    this.descargar(new Blob([csv], { type: 'text/csv' }), 'sherlock-dashboard.csv');
  }

  /** Sin endpoint de export PDF propio de este remoto (ver comentario de
   * cabecera de la clase) — export client-side vía impresión del navegador. */
  protected exportarPdf(): void {
    window.print();
  }

  private descargar(blob: Blob, nombreArchivo: string): void {
    const url = URL.createObjectURL(blob);
    const enlace = document.createElement('a');
    enlace.href = url;
    enlace.download = nombreArchivo;
    enlace.click();
    URL.revokeObjectURL(url);
  }
}
