import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { EstadoFuente } from '../core/dashboard.model';

const ETIQUETA_ESTADO: Record<EstadoFuente['estado'], string> = {
  OK: 'Sincronizada',
  DESACTUALIZADA: 'Desactualizada',
  SIN_DATOS: 'Sin datos',
  ERROR: 'Error',
};

/**
 * Panel "Fuentes de Exposición" (pantalla 01): 6 tiles de estado (Tenable IE,
 * Virtual Patching, Carpetas, Admins, Spider, ACL). No es una HU con número
 * propio en el backlog analizado, pero forma parte del layout de dashboard
 * que TT-13 pide montar junto a HU-07/HU-08 — se incluye porque el dato ya
 * lo expone el mismo endpoint (`GET /api/sources/status`) documentado en
 * `documento-funcional-tecnico-pantallas.html`.
 */
@Component({
  selector: 'app-sources-status',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="sources-status sk-card">
      <h3 class="sk-heading">Fuentes de exposición</h3>
      <div class="sources-status__grid">
        @for (fuente of fuentes(); track fuente.fuenteId) {
          <div class="sources-status__tile" [class]="'sources-status__tile--' + fuente.estado.toLowerCase()">
            <span class="sources-status__nombre">{{ fuente.nombre }}</span>
            <span class="sources-status__estado">{{ etiqueta(fuente.estado) }}</span>
          </div>
        }
      </div>
    </div>
  `,
  styles: `
    .sources-status__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px; margin-top: 10px; }
    .sources-status__tile { border: 1px solid var(--sk-color-border, #d9dadd); border-radius: 8px; padding: 10px; display: flex; flex-direction: column; gap: 4px; border-left: 4px solid transparent; }
    .sources-status__tile--ok { border-left-color: #00c389; }
    .sources-status__tile--desactualizada { border-left-color: #fdda24; }
    .sources-status__tile--sin_datos { border-left-color: #d9dadd; }
    .sources-status__tile--error { border-left-color: #e20201; }
    .sources-status__nombre { font-weight: 700; font-size: 0.8rem; }
    .sources-status__estado { font-size: 0.7rem; color: var(--sk-color-text-muted, #666b73); }
  `,
})
export class SourcesStatus {
  readonly fuentes = input.required<EstadoFuente[]>();

  protected etiqueta(estado: EstadoFuente['estado']): string {
    return ETIQUETA_ESTADO[estado];
  }
}
