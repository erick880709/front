import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

/**
 * Indicador de Estado de Riesgo Global (HU-07): porcentaje + barra de
 * progreso + badge de nivel (pantalla 01, "72% · HIGH RISK").
 *
 * CA2 ("se recalcula con cada actualización de datos, sin requerir refresco
 * manual de página") se resuelve en el componente padre (`App`, ver
 * `app.ts`): el valor llega por `@Input()` desde un observable que se
 * re-suscribe periódicamente, así que este componente, al ser `OnPush` y
 * basado en `input()`, se repinta solo cuando cambia el dato — sin que el
 * usuario tenga que recargar la pestaña.
 */
@Component({
  selector: 'app-risk-indicator',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="risk-indicator sk-card">
      <div class="risk-indicator__cabecera">
        <h3 class="sk-heading">Estado de Riesgo Global</h3>
        <span class="risk-indicator__badge" [class]="claseBadge()">{{ nivel() }}</span>
      </div>
      <p class="risk-indicator__porcentaje">{{ porcentaje() }}%</p>
      <div class="risk-indicator__barra" role="progressbar" [attr.aria-valuenow]="porcentaje()" aria-valuemin="0" aria-valuemax="100">
        <div class="risk-indicator__barra-relleno" [style.width.%]="porcentaje()"></div>
      </div>
    </div>
  `,
  styles: `
    .risk-indicator__cabecera { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .risk-indicator__badge {
      font-size: 0.7rem;
      font-weight: 700;
      padding: 3px 10px;
      border-radius: 10px;
      color: #fff;
      text-transform: uppercase;
    }
    .risk-indicator__badge--critico { background: #e20201; }
    .risk-indicator__badge--alto { background: #ff7f41; }
    .risk-indicator__badge--medio { background: #fdda24; color: #2c2a29; }
    .risk-indicator__badge--bajo { background: #00c389; }
    .risk-indicator__porcentaje { font-size: 2.4rem; font-weight: 700; margin: 8px 0; }
    .risk-indicator__barra { height: 10px; border-radius: 6px; background: var(--sk-color-surface-alt, #f2f2f4); overflow: hidden; }
    .risk-indicator__barra-relleno { height: 100%; background: #e20201; transition: width 0.3s ease; }
  `,
})
export class RiskIndicator {
  readonly porcentaje = input.required<number>();
  readonly nivel = input.required<string>();

  protected readonly claseBadge = computed(() => {
    const p = this.porcentaje();
    if (p >= 75) return 'risk-indicator__badge risk-indicator__badge--critico';
    if (p >= 50) return 'risk-indicator__badge risk-indicator__badge--alto';
    if (p >= 25) return 'risk-indicator__badge risk-indicator__badge--medio';
    return 'risk-indicator__badge risk-indicator__badge--bajo';
  });
}
