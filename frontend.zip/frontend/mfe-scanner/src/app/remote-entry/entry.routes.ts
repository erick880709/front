import { Routes } from '@angular/router';

/**
 * Rutas expuestas vía Native Federation (federation.config.js → exposes['./Routes']).
 * El shell las monta bajo /scanner con loadChildren; el path aquí es relativo a ese prefijo.
 */
export const SCANNER_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('../scanner/scanner-landing/scanner-landing').then((m) => m.ScannerLanding),
  },
  {
    path: 'resultado/:jobId',
    loadComponent: () =>
      import('../scanner/scanner-resultado/scanner-resultado').then((m) => m.ScannerResultado),
  },
];
