import { Injectable, signal } from '@angular/core';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { AnalisisReciente, ResultadoScanner } from '../../shared/models/scanner.model';

const ANALISIS_RECIENTES: AnalisisReciente[] = [
  { id: 'job-1', objetivo: 'malicious-payload.exe', tipo: 'Hash MD5', severidad: 'critico', etiqueta: 'CRÍTICO', fechaRelativa: 'hace 12 min' },
  { id: 'job-2', objetivo: '185.220.101.45', tipo: 'IP', severidad: 'alto', etiqueta: 'ALTO', fechaRelativa: 'hace 1 h' },
  { id: 'job-3', objetivo: 'portal-clientes-bancolombia.net', tipo: 'Dominio', severidad: 'alto', etiqueta: 'ALTO', fechaRelativa: 'hace 3 h' },
  { id: 'job-4', objetivo: 'https://drive.google.com/file/d/abc', tipo: 'URL', severidad: 'sin-riesgo', etiqueta: 'SIN RIESGO', fechaRelativa: 'ayer' },
  { id: 'job-5', objetivo: '190.85.0.0/16', tipo: 'CIDR', severidad: 'sin-riesgo', etiqueta: 'SIN RIESGO', fechaRelativa: 'hace 2 días' },
];

const RESULTADOS: Record<string, ResultadoScanner> = {
  'job-1': {
    jobId: 'job-1',
    objetivo: 'malicious-payload.exe',
    score: 82,
    nivelRiesgo: 'Riesgo alto',
    severidad: 'alto',
    totalFuentes: 16,
    fuentesConDatos: 16,
    fuentesConsultadas: [
      { nombre: 'VirusTotal', valor: '48/72 motores', severidad: 'critico' },
      { nombre: 'URLScan', valor: 'Sin coincidencias', severidad: 'sin-riesgo' },
      { nombre: 'GreyNoise', valor: 'No observado', severidad: 'sin-riesgo' },
      { nombre: 'WHOIS', valor: 'Registro reciente', severidad: 'medio' },
      { nombre: 'Mandiant', valor: 'Asociado a APT-29', severidad: 'critico' },
      { nombre: 'SOCRadar', valor: 'Presente en feed', severidad: 'alto' },
      { nombre: 'AbuseIPDB', valor: 'Confianza 92%', severidad: 'alto' },
      { nombre: 'Fortra', valor: 'Sin reportes', severidad: 'sin-riesgo' },
    ],
    iocs: ['malicious-payload.exe', '185.220.101.45', 'C2-panel.dark-net.io'],
  },
};

const RESULTADO_DEFECTO: ResultadoScanner = RESULTADOS['job-1'];

@Injectable({ providedIn: 'root' })
export class ScannerService {
  private readonly _analisisRecientes = signal<AnalisisReciente[]>(ANALISIS_RECIENTES);
  readonly analisisRecientes = this._analisisRecientes.asReadonly();

  analizarObjetivo(objetivo: string) {
    return of({ jobId: 'job-1', objetivo }).pipe(delay(600));
  }

  obtenerResultado(jobId: string) {
    return of(RESULTADOS[jobId] ?? { ...RESULTADO_DEFECTO, jobId }).pipe(delay(300));
  }
}
