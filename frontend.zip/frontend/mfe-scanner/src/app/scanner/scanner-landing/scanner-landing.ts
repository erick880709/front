import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { PocDisclaimer } from '../../shared/layout/poc-disclaimer/poc-disclaimer';
import { SeverityBadge } from '../../shared/ui/severity-badge/severity-badge';
import { ScannerService } from '../../core/services/scanner.service';

const HINTS = ['URL', 'Dominio', 'IP', 'Hash MD5', 'CIDR'] as const;

@Component({
  selector: 'apex-scanner-landing',
  standalone: true,
  imports: [FormsModule, PocDisclaimer, SeverityBadge],
  templateUrl: './scanner-landing.html',
  styleUrl: './scanner-landing.scss',
})
export class ScannerLanding {
  private readonly scannerService = inject(ScannerService);
  private readonly router = inject(Router);

  readonly hints = HINTS;
  readonly analisisRecientes = this.scannerService.analisisRecientes;

  objetivo = signal('');
  analizando = signal(false);

  analizarObjetivo() {
    const valor = this.objetivo().trim();
    if (!valor || this.analizando()) {
      return;
    }
    this.analizando.set(true);
    this.scannerService.analizarObjetivo(valor).subscribe((resultado) => {
      this.analizando.set(false);
      this.router.navigate(['/scanner/resultado', resultado.jobId]);
    });
  }

  abrirAnalisis(jobId: string) {
    this.router.navigate(['/scanner/resultado', jobId]);
  }
}
