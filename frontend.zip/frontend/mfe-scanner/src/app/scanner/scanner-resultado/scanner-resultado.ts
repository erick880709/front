import { Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { map, switchMap } from 'rxjs/operators';

import { PocDisclaimer } from '../../shared/layout/poc-disclaimer/poc-disclaimer';
import { SeverityBadge } from '../../shared/ui/severity-badge/severity-badge';
import { ScannerService } from '../../core/services/scanner.service';

@Component({
  selector: 'apex-scanner-resultado',
  standalone: true,
  imports: [RouterLink, PocDisclaimer, SeverityBadge],
  templateUrl: './scanner-resultado.html',
  styleUrl: './scanner-resultado.scss',
})
export class ScannerResultado {
  private readonly route = inject(ActivatedRoute);
  private readonly scannerService = inject(ScannerService);
  private readonly router = inject(Router);

  readonly analisisRecientes = this.scannerService.analisisRecientes;

  readonly jobId = toSignal(this.route.paramMap.pipe(map((params) => params.get('jobId') ?? '')), {
    initialValue: '',
  });

  readonly resultado = toSignal(
    this.route.paramMap.pipe(switchMap((params) => this.scannerService.obtenerResultado(params.get('jobId') ?? ''))),
    { initialValue: undefined },
  );

  seleccionarHistorico(jobId: string) {
    this.router.navigate(['/scanner/resultado', jobId]);
  }
}
