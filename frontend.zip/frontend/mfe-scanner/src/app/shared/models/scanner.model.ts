import { Severity } from '../ui/severity-badge/severity-badge';

export interface AnalisisReciente {
  id: string;
  objetivo: string;
  tipo: 'URL' | 'Dominio' | 'IP' | 'Hash MD5' | 'CIDR';
  severidad: Severity;
  etiqueta: string;
  fechaRelativa: string;
}

export interface FuenteConsultada {
  nombre: string;
  valor: string;
  severidad: Severity;
}

export interface ResultadoScanner {
  jobId: string;
  objetivo: string;
  score: number;
  nivelRiesgo: string;
  severidad: Severity;
  fuentesConsultadas: FuenteConsultada[];
  totalFuentes: number;
  fuentesConDatos: number;
  iocs: string[];
}
