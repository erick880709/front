import { Routes } from '@angular/router';

/**
 * Rutas usadas solo cuando este remoto se sirve en modo standalone (`ng serve`, puerto 4201)
 * para probarlo de forma aislada. Se montan bajo /scanner (igual que en el shell) porque los
 * componentes navegan con rutas absolutas ('/scanner/resultado/:jobId') pensadas para ese prefijo.
 */
export const routes: Routes = [
  { path: '', redirectTo: 'scanner', pathMatch: 'full' },
  { path: 'scanner', loadComponent: () => import('./scanner/scanner-landing/scanner-landing').then((m) => m.ScannerLanding) },
  {
    path: 'scanner/resultado/:jobId',
    loadComponent: () => import('./scanner/scanner-resultado/scanner-resultado').then((m) => m.ScannerResultado),
  },
  { path: '**', redirectTo: 'scanner' },
];
