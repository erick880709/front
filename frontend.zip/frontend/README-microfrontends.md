# Apex Radar Intelligence — Frontend como microfrontends

Este directorio contiene **4 aplicaciones Angular 21 independientes**, integradas
en tiempo de ejecución con [Native Federation](https://www.npmjs.com/package/@angular-architects/native-federation):

| App | Rol | Puerto dev | Expone |
|---|---|---|---|
| `apex-shell` | Host — chrome (Topbar), routing raíz, consume los 3 remotos | 4200 | — |
| `mfe-scanner` | Remoto — pantallas Scanner (landing + resultado) | 4201 | `./Routes` → `SCANNER_ROUTES` |
| `mfe-avd` | Remoto — pantalla AVD (análisis) | 4202 | `./Routes` → `AVD_ROUTES` |
| `mfe-telegram` | Remoto — pantalla Telegram Intel | 4203 | `./Routes` → `TELEGRAM_ROUTES` |

> **Nota de arquitectura:** el diagrama de despliegue entregado por el banco
> (RT-002, RT-005) define una sola SPA Angular servida como contenido estático
> en S3+CloudFront. Esta estructura de 4 microfrontends es una **decisión
> explícita del equipo, tomada por fuera de ese baseline**, documentada y con
> sus implicancias en
> [`resources/architecture/definitions/RT-019-frontend-microfrontends-decision.md`](../resources/architecture/definitions/RT-019-frontend-microfrontends-decision.md).
> Debe validarse con el equipo de arquitectura del banco antes de cualquier
> despliegue real a AWS (impacta CI/CD, WAF, número de distribuciones CloudFront).

## Por qué Native Federation y no Module Federation clásico

Angular 21 usa por defecto el builder `@angular/build:application` (esbuild),
no Webpack. El Module Federation clásico de Webpack no es compatible con ese
builder. Native Federation logra el mismo resultado (carga de remotos en
runtime, dependencias compartidas como singleton) sin depender de Webpack —
es la opción recomendada por el propio ecosistema Angular para este escenario.

## Requisitos

Node.js 20+ y npm. **Este scaffold sí fue instalado, compilado y levantado
localmente** (2026-08-19) con Node v24.19.0/npm 11.17.0 — no se escribió a
ciegas. El `angular.json` de las 4 apps se generó ejecutando el schematic real
(`ng generate @angular-architects/native-federation:init --project <app>
--port <puerto> --type remote|dynamic-host`), no a mano, y las 4 compilan
(`npm run build`) sin warnings ni errores. Ver también
[RT-019](../resources/architecture/definitions/RT-019-frontend-microfrontends-decision.md)
para el detalle de la validación.

```bash
# Por cada una de las 4 carpetas (apex-shell, mfe-scanner, mfe-avd, mfe-telegram)
cd frontend/<carpeta>
npm install
```

Si en tu máquina `npm install` resuelve versiones distintas de
`@angular-architects/native-federation`/`@angular/build` y algo no coincide,
vuelve a correr el schematic de init sobre un `angular.json` "limpio" (builder
`@angular/build:application` en `build`, `@angular/build:dev-server` en
`serve` — sin el wrapper de federación) — es el método que se usó aquí y el
más confiable, más que editar `angular.json` a mano.

## Cómo probar todo el sistema federado localmente

Necesitas los 4 servidores de desarrollo corriendo a la vez, cada uno en su
puerto. Desde 4 terminales distintas (o usando el script de abajo):

```bash
cd frontend/mfe-scanner  && npm start   # http://localhost:4201
cd frontend/mfe-avd      && npm start   # http://localhost:4202
cd frontend/mfe-telegram && npm start   # http://localhost:4203
cd frontend/apex-shell   && npm start   # http://localhost:4200  ← abre este
```

Los remotos deben arrancar **antes o al mismo tiempo** que el shell (Native
Federation resuelve `remoteEntry.json` de cada uno al bootstrapear el shell).
Abre `http://localhost:4200` — debe verse el Topbar del shell con navegación a
Scanner/AVD/Telegram, cargando cada pantalla desde su remoto correspondiente.

### Atajo: script que levanta las 4 apps

`serve-all.ps1` (PowerShell) y `serve-all.sh` (bash) instalan dependencias (si
hace falta) y arrancan las 4 apps en paralelo. Ver más abajo.

## Probar un remoto de forma aislada

Cada remoto también corre standalone (sin el shell) para desarrollo/QA de esa
pantalla sola, sin el Topbar del shell:

```bash
cd frontend/mfe-scanner && npm start   # http://localhost:4201/scanner
cd frontend/mfe-avd      && npm start   # http://localhost:4202
cd frontend/mfe-telegram && npm start   # http://localhost:4203
```

## Despliegue (una vez validado con el banco)

Cada app se compila y despliega por separado:

```bash
cd frontend/<carpeta>
npm run build   # genera dist/<carpeta>, contenido estático
```

En AWS, cada `dist/<carpeta>` se sube a su propio bucket S3 + distribución
CloudFront (o a un path dedicado bajo la misma distribución). El
`federation.manifest.json` del shell (`apex-shell/public/federation.manifest.json`)
debe actualizarse para apuntar a las URLs reales de `remoteEntry.json` de cada
remoto desplegado, en vez de `localhost`.

## Deuda técnica conocida de este scaffold

- **UI compartida duplicada:** `SeverityBadge`, `PocDisclaimer` y los modelos
  TypeScript están duplicados en los 3 remotos (cada uno es un proyecto Angular
  independiente). Es un trade-off aceptado de microfrontends con despliegue
  independiente; si la duplicación se vuelve difícil de mantener, extraer un
  paquete npm interno (`@apex/ui-kit`) publicado en el registry del banco y
  consumido por los 3 remotos + el shell.
- **7 vulnerabilidades reportadas por `npm audit`** (4 moderate, 3 high) en las
  4 apps — heredadas de la cadena de dependencias de `@angular/build`/esbuild,
  no de código propio. Revisar con `npm audit` antes de producción.
- **Datos mock:** los 3 servicios (`ScannerService`, `AvdService`,
  `TelegramService`) devuelven datos de ejemplo fijos — no hay backend real
  conectado todavía. Es intencional (maqueta), no un bug.
