import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { PocDisclaimer } from '../../shared/layout/poc-disclaimer/poc-disclaimer';
import { SeverityBadge } from '../../shared/ui/severity-badge/severity-badge';
import { AvdService } from '../../core/services/avd.service';
import { AvdTab, ResultadoAvd } from '../../shared/models/avd.model';

const TABS: { id: AvdTab; label: string }[] = [
  { id: 'resumen', label: 'Resumen Ejecutivo' },
  { id: 'identidad', label: 'Identidad' },
  { id: 'presencia-digital', label: 'Presencia Digital' },
  { id: 'breaches', label: 'Breaches' },
  { id: 'timeline', label: 'Timeline' },
  { id: 'comportamiento', label: 'Comportamiento' },
];

@Component({
  selector: 'apex-avd-analisis',
  standalone: true,
  imports: [FormsModule, PocDisclaimer, SeverityBadge],
  templateUrl: './avd-analisis.html',
  styleUrl: './avd-analisis.scss',
})
export class AvdAnalisis {
  private readonly avdService = inject(AvdService);

  readonly tabs = TABS;
  readonly historico = this.avdService.historico;

  textoOsint = signal('');
  archivoNombre = signal<string | null>(null);
  analizando = signal(false);
  mostrarHistorial = signal(false);
  tabActiva = signal<AvdTab>('resumen');
  resultado = signal<ResultadoAvd | null>(null);

  onArchivoSeleccionado(event: Event) {
    const input = event.target as HTMLInputElement;
    this.archivoNombre.set(input.files?.[0]?.name ?? null);
  }

  analizar() {
    if (this.analizando()) {
      return;
    }
    this.analizando.set(true);
    this.avdService.analizar({ textoOsint: this.textoOsint() }).subscribe((resultado) => {
      this.resultado.set(resultado);
      this.analizando.set(false);
    });
  }

  toggleHistorial() {
    this.mostrarHistorial.update((v) => !v);
  }

  seleccionarHistorico(id: string) {
    this.avdService.obtenerAnalisis(id).subscribe((resultado) => {
      this.resultado.set(resultado);
      this.mostrarHistorial.set(false);
    });
  }

  seleccionarTab(tab: AvdTab) {
    this.tabActiva.set(tab);
  }
}
