import { Injectable, signal } from '@angular/core';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { AnalisisAvdHistorico, ResultadoAvd } from '../../shared/models/avd.model';

const HISTORICO: AnalisisAvdHistorico[] = [
  { id: 'avd-1', sujeto: 'Juan Carlos Restrepo', fechaRelativa: 'hace 2 h' },
  { id: 'avd-2', sujeto: 'María Fernanda Gómez', fechaRelativa: 'ayer' },
  { id: 'avd-3', sujeto: 'proveedor-externo@dominio.com', fechaRelativa: 'hace 3 días' },
  { id: 'avd-4', sujeto: 'Andrés Felipe Zuluaga', fechaRelativa: 'hace 1 semana' },
];

const RESULTADO: ResultadoAvd = {
  id: 'avd-1',
  sujeto: 'Juan Carlos Restrepo',
  briefingIa:
    'El sujeto presenta exposición digital significativa: 3 brechas de datos confirmadas con credenciales asociadas ' +
    'y actividad reciente en foros de bajo perfil. Se recomienda monitoreo continuo y validación de accesos privilegiados.',
  alertasCriticas: [
    { titulo: 'Credencial comprometida activa', descripcion: 'Contraseña reutilizada encontrada en breach de 2025 aún vigente en un sistema interno.' },
    { titulo: 'Mención en foro de cibercrimen', descripcion: 'Correo corporativo mencionado en un hilo de venta de accesos VPN.' },
  ],
  matrizRiesgo: [
    { categoria: 'Exposición de credenciales', nivel: 'alto', justificacion: '3 breaches confirmados, 1 credencial reutilizada activa.' },
    { categoria: 'Presencia en redes sociales', nivel: 'medio', justificacion: 'Perfiles públicos con información laboral detallada.' },
    { categoria: 'Actividad en foros underground', nivel: 'alto', justificacion: 'Mención directa en foro de venta de accesos.' },
    { categoria: 'Higiene de seguridad personal', nivel: 'medio', justificacion: 'Reutilización de contraseñas detectada entre servicios.' },
    { categoria: 'Superficie de ataque OSINT', nivel: 'bajo', justificacion: 'Baja cantidad de metadatos expuestos en documentos públicos.' },
    { categoria: 'Riesgo reputacional', nivel: 'bajo', justificacion: 'Sin menciones negativas en medios o prensa.' },
  ],
};

@Injectable({ providedIn: 'root' })
export class AvdService {
  private readonly _historico = signal<AnalisisAvdHistorico[]>(HISTORICO);
  readonly historico = this._historico.asReadonly();

  analizar(_input: { archivo?: File; textoOsint?: string }) {
    return of(RESULTADO).pipe(delay(600));
  }

  obtenerAnalisis(id: string) {
    return of({ ...RESULTADO, id }).pipe(delay(300));
  }
}
