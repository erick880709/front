import { Routes } from '@angular/router';

/**
 * Rutas usadas solo cuando este remoto se sirve en modo standalone (`ng serve`, puerto 4202)
 * para probarlo de forma aislada. Deben mantenerse equivalentes a remote-entry/entry.routes.ts.
 */
export const routes: Routes = [
  { path: '', loadComponent: () => import('./avd/avd-analisis/avd-analisis').then((m) => m.AvdAnalisis) },
  { path: '**', redirectTo: '' },
];
