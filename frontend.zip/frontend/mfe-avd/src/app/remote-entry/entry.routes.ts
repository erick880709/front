import { Routes } from '@angular/router';

/**
 * Rutas expuestas vía Native Federation (federation.config.js → exposes['./Routes']).
 * El shell las monta bajo /avd con loadChildren; el path aquí es relativo a ese prefijo.
 */
export const AVD_ROUTES: Routes = [
  { path: '', loadComponent: () => import('../avd/avd-analisis/avd-analisis').then((m) => m.AvdAnalisis) },
];
