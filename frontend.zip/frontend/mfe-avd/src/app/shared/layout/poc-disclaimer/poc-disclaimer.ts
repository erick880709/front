import { Component, input } from '@angular/core';

/**
 * Descargo de responsabilidad de prueba de concepto (obligatorio, no negociable
 * mientras el sistema no sea un canal oficial — ver poc-and-disclaimers.md de
 * la skill bancolombia-ui-ux). Cada pantalla pasa su propio texto de contexto.
 */
@Component({
  selector: 'apex-poc-disclaimer',
  standalone: true,
  templateUrl: './poc-disclaimer.html',
  styleUrl: './poc-disclaimer.scss',
})
export class PocDisclaimer {
  message = input('Prueba de concepto ilustrativa. No representa un canal oficial de Bancolombia S.A.');
}
