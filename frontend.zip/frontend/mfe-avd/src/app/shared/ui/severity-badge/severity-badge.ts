import { Component, computed, input } from '@angular/core';

export type Severity = 'critico' | 'alto' | 'medio' | 'bajo' | 'sin-riesgo';

const DEFAULT_LABELS: Record<Severity, string> = {
  critico: 'Crítico',
  alto: 'Alto',
  medio: 'Medio',
  bajo: 'Bajo',
  'sin-riesgo': 'Sin riesgo',
};

@Component({
  selector: 'apex-severity-badge',
  standalone: true,
  templateUrl: './severity-badge.html',
  styleUrl: './severity-badge.scss',
})
export class SeverityBadge {
  severity = input.required<Severity>();
  label = input<string>();

  displayLabel = computed(() => this.label() ?? DEFAULT_LABELS[this.severity()]);
}
