import { Severity } from '../ui/severity-badge/severity-badge';

export type AvdTab = 'resumen' | 'identidad' | 'presencia-digital' | 'breaches' | 'timeline' | 'comportamiento';

export interface RiesgoAvd {
  categoria: string;
  nivel: Severity;
  justificacion: string;
}

export interface AlertaCritica {
  titulo: string;
  descripcion: string;
}

export interface AnalisisAvdHistorico {
  id: string;
  sujeto: string;
  fechaRelativa: string;
}

export interface ResultadoAvd {
  id: string;
  sujeto: string;
  briefingIa: string;
  alertasCriticas: AlertaCritica[];
  matrizRiesgo: RiesgoAvd[];
}
