import { initFederation } from '@angular-architects/native-federation';

/**
 * initFederation() sin manifest: este remoto no consume otros remotos, solo necesita
 * inicializar su propio shared scope antes de bootstrap (requerido incluso cuando se
 * sirve en modo standalone para pruebas aisladas, puerto 4202).
 */
initFederation()
  .catch((err) => console.error(err))
  .then(() => import('./bootstrap'))
  .catch((err) => console.error(err));
