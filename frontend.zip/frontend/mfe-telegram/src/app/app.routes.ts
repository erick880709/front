import { Routes } from '@angular/router';

/**
 * Rutas usadas solo cuando este remoto se sirve en modo standalone (`ng serve`, puerto 4203)
 * para probarlo de forma aislada. Deben mantenerse equivalentes a remote-entry/entry.routes.ts.
 */
export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./telegram/telegram-intel/telegram-intel').then((m) => m.TelegramIntel),
  },
  { path: '**', redirectTo: '' },
];
