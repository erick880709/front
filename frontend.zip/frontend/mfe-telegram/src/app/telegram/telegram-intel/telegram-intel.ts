import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { PocDisclaimer } from '../../shared/layout/poc-disclaimer/poc-disclaimer';
import { SeverityBadge, Severity } from '../../shared/ui/severity-badge/severity-badge';
import { TelegramService } from '../../core/services/telegram.service';

const SEVERIDADES: Severity[] = ['critico', 'alto', 'medio', 'bajo'];

@Component({
  selector: 'apex-telegram-intel',
  standalone: true,
  imports: [FormsModule, PocDisclaimer, SeverityBadge],
  templateUrl: './telegram-intel.html',
  styleUrl: './telegram-intel.scss',
})
export class TelegramIntel {
  private readonly telegramService = inject(TelegramService);

  readonly severidades = SEVERIDADES;
  readonly estadisticas = this.telegramService.estadisticas;
  readonly resultados = this.telegramService.resultados;

  palabraClave = signal('');
  limite = signal(50);
  buscando = signal(false);

  filtroTexto = signal('');
  filtroCanal = signal('');
  filtroSeveridad = signal<Severity | null>(null);

  resultadosFiltrados = computed(() => {
    const texto = this.filtroTexto().toLowerCase();
    const canal = this.filtroCanal().toLowerCase();
    const severidad = this.filtroSeveridad();

    return this.resultados().filter((r) => {
      const coincideTexto = !texto || r.titulo.toLowerCase().includes(texto);
      const coincideCanal = !canal || r.canal.toLowerCase().includes(canal);
      const coincideSeveridad = !severidad || r.severidad === severidad;
      return coincideTexto && coincideCanal && coincideSeveridad;
    });
  });

  buscar() {
    if (this.buscando()) {
      return;
    }
    this.buscando.set(true);
    this.telegramService.buscar(this.palabraClave(), this.limite()).subscribe(() => {
      this.buscando.set(false);
    });
  }

  toggleFiltroSeveridad(severidad: Severity) {
    this.filtroSeveridad.set(this.filtroSeveridad() === severidad ? null : severidad);
  }
}
