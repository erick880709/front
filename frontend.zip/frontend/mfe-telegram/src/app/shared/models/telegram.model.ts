import { Severity } from '../ui/severity-badge/severity-badge';

export interface ResultadoTir {
  id: string;
  titulo: string;
  severidad: Severity;
  canal: string;
  unido: boolean;
  fechaRelativa: string;
}

export interface EstadisticasTelegram {
  totalMensajes: number;
  totalCanales: number;
  porSeveridad: Record<Severity, number>;
}
