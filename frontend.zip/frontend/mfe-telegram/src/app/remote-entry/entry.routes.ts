import { Routes } from '@angular/router';

/**
 * Rutas expuestas vía Native Federation (federation.config.js → exposes['./Routes']).
 * El shell las monta bajo /telegram con loadChildren; el path aquí es relativo a ese prefijo.
 */
export const TELEGRAM_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('../telegram/telegram-intel/telegram-intel').then((m) => m.TelegramIntel),
  },
];
