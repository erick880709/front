import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * Root usado solo para servir mfe-telegram en modo standalone (`ng serve`, puerto 4203)
 * y como ancla de bootstrap para Native Federation. Cuando el shell federa esta app,
 * el chrome (Topbar) lo aporta apex-shell — este remoto solo expone contenido de ruta.
 */
@Component({
  selector: 'apex-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.html',
})
export class App {}
