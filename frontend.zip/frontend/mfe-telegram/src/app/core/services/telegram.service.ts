import { Injectable, signal } from '@angular/core';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { EstadisticasTelegram, ResultadoTir } from '../../shared/models/telegram.model';

const RESULTADOS: ResultadoTir[] = [
  {
    id: 'tir-1',
    titulo: 'Venta de base de datos de clientes con credenciales bancarias',
    severidad: 'critico',
    canal: 'darkmarket_co',
    unido: false,
    fechaRelativa: 'hace 25 min',
  },
  {
    id: 'tir-2',
    titulo: 'Oferta de acceso VPN corporativo sector financiero',
    severidad: 'alto',
    canal: 'access_broker_ls',
    unido: true,
    fechaRelativa: 'hace 2 h',
  },
  {
    id: 'tir-3',
    titulo: 'Mención genérica de phishing bancario en Colombia',
    severidad: 'medio',
    canal: 'osint_colombia',
    unido: false,
    fechaRelativa: 'hace 5 h',
  },
];

const ESTADISTICAS: EstadisticasTelegram = {
  totalMensajes: 1284,
  totalCanales: 37,
  porSeveridad: { critico: 4, alto: 11, medio: 22, bajo: 9, 'sin-riesgo': 0 },
};

@Injectable({ providedIn: 'root' })
export class TelegramService {
  private readonly _resultados = signal<ResultadoTir[]>(RESULTADOS);
  readonly resultados = this._resultados.asReadonly();

  private readonly _estadisticas = signal<EstadisticasTelegram>(ESTADISTICAS);
  readonly estadisticas = this._estadisticas.asReadonly();

  buscar(_palabraClave: string, _limite: number) {
    return of(RESULTADOS).pipe(delay(600));
  }
}
