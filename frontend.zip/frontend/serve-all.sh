#!/usr/bin/env bash
# Instala dependencias (si hace falta) y levanta los 4 microfrontends de Apex Radar Intelligence
# en background: mfe-scanner (4201), mfe-avd (4202), mfe-telegram (4203), apex-shell (4200).
# Ejecutar desde la carpeta frontend/. Ctrl+C detiene todos los procesos hijos.

set -e
root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
apps=(mfe-scanner mfe-avd mfe-telegram apex-shell)

for app in "${apps[@]}"; do
  if [ ! -d "$root/$app/node_modules" ]; then
    echo "Instalando dependencias de $app..."
    (cd "$root/$app" && npm install)
  fi
done

pids=()
cleanup() {
  echo "Deteniendo microfrontends..."
  for pid in "${pids[@]}"; do
    kill "$pid" 2>/dev/null || true
  done
}
trap cleanup EXIT INT TERM

for app in "${apps[@]}"; do
  echo "Levantando $app..."
  (cd "$root/$app" && npm start) &
  pids+=($!)
  if [ "$app" != "apex-shell" ]; then
    sleep 3
  fi
done

echo ""
echo "Shell disponible en http://localhost:4200 (dale unos segundos a los 4 servidores para terminar de compilar)."
wait
