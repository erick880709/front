# Instala dependencias (si hace falta) y levanta los 4 microfrontends de Apex Radar Intelligence
# en ventanas separadas de PowerShell: mfe-scanner (4201), mfe-avd (4202), mfe-telegram (4203),
# apex-shell (4200). Ejecutar desde la carpeta frontend/.

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$apps = @('mfe-scanner', 'mfe-avd', 'mfe-telegram', 'apex-shell')

foreach ($app in $apps) {
    $path = Join-Path $root $app
    if (-not (Test-Path (Join-Path $path 'node_modules'))) {
        Write-Host "Instalando dependencias de $app..."
        Push-Location $path
        npm install
        Pop-Location
    }
}

foreach ($app in $apps) {
    $path = Join-Path $root $app
    Write-Host "Levantando $app..."
    Start-Process powershell -ArgumentList '-NoExit', '-Command', "cd `"$path`"; npm start"
    if ($app -ne 'apex-shell') {
        Start-Sleep -Seconds 3
    }
}

Write-Host ""
Write-Host "Shell disponible en http://localhost:4200 (dale unos segundos a los 4 servidores para terminar de compilar)."
