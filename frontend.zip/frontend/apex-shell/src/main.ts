import { initFederation } from '@angular-architects/native-federation';

/**
 * El manifest lista la URL de remoteEntry.json de cada MFE remoto (Scanner/AVD/Telegram).
 * En local apunta a los puertos de `ng serve` de cada remoto (ver frontend/README-microfrontends.md);
 * en despliegue real cada entrada debe apuntar a la CloudFront distribution de ese remoto.
 */
initFederation('federation.manifest.json')
  .catch((err) => console.error(err))
  .then(() => import('./bootstrap'))
  .catch((err) => console.error(err));
