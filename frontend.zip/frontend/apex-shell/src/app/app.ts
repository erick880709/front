import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { Topbar } from './shared/layout/topbar/topbar';

@Component({
  selector: 'apex-root',
  standalone: true,
  imports: [RouterOutlet, Topbar],
  templateUrl: './app.html',
})
export class App {}
