import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';

/**
 * Zoneless por defecto (Angular 21) — sin zone.js. Cualquier cambio de estado
 * debe pasar por Signals o markForCheck explícito; no depender de detección
 * de cambios implícita por eventos async fuera de Angular.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes),
  ],
};
