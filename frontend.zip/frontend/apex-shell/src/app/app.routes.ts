import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';

export const routes: Routes = [
  { path: '', redirectTo: 'scanner', pathMatch: 'full' },
  {
    path: 'scanner',
    loadChildren: () =>
      loadRemoteModule('mfeScanner', './Routes').then((m) => m.SCANNER_ROUTES),
  },
  {
    path: 'avd',
    loadChildren: () =>
      loadRemoteModule('mfeAvd', './Routes').then((m) => m.AVD_ROUTES),
  },
  {
    path: 'telegram',
    loadChildren: () =>
      loadRemoteModule('mfeTelegram', './Routes').then((m) => m.TELEGRAM_ROUTES),
  },
  { path: '**', redirectTo: 'scanner' },
];
