# Cómo importar estos mockups a Figma

Esta carpeta contiene las 12 pantallas de SherLock en **SVG** (vector, editable),
rediseñadas sobre el **Design System real de Bancolombia** ("Caribe" / BDS
`ng_bds` versión **9.38.7**), el mismo que usa el proyecto SherLock según sus
requerimientos ("sistema de diseño Caribe").

## Auditoría de cobertura de componentes reales

El storybook real (`.../storybook/index.json`) cataloga **71 componentes**
únicos en Atoms/Molecules/Organisms. No todos aplican a un dashboard de
seguridad (hay componentes de tarjetas de crédito, calendario, autenticación
transaccional, etc. que no tienen cabida aquí) — la tabla siguiente es la
auditoría honesta de cuáles se usaron, cuáles se corrigieron tras una primera
revisión, y cuáles no aplican y por qué.

| Componente real | Estado en los 12 mockups | Detalle |
|---|---|---|
| **Atoms/Avatar** | ✅ Usado (agregado en esta auditoría) | Círculo 100% radio, sombra shadow-06, borde blanco 2px, iniciales sobre color temático (`.bc-avatar-initials-caribe/alba/...`). Usado en el header (analista autenticado) y junto al campo "Owner" de cada servidor. |
| **Atoms/Badge** | ✅ Usado | Severidad (CRIT/HIGH/MED/LOW) y tags de conteo, colores `.bc-badge-red/yellow/green` reales. |
| **Atoms/Button** | ✅ Usado | Variantes primary/secondary/tertiary reales (`.bc-button-primary/-secondary/-tertiary`). |
| **Atoms/ButtonGroup** | ✅ Usado (corregido) | El control Horizontal/Vertical/Libre del grafo usaba 3 botones sueltos; se reemplazó por el patrón real de contenedor-píldora segmentado (`.bc-button-group-container`). |
| **Atoms/CardContainer** | ✅ Usado | Base de todas las tarjetas/paneles blancos con sombra sutil. |
| **Atoms/ProgressBar** | ✅ Usado (color corregido) | Barra de "Estado de Riesgo Global"; el relleno naranja inicial no es una variante real de `.bc-progress-bar-lineal-value` — se corrigió a rojo, que sí lo es. |
| **Atoms/IconButton** | ⚠️ Aproximado | Los botones cuadrados de expandir/cerrar del modal existen como forma, pero sin el glyph real de la fuente de iconos `BC Icons` (no se pudo descargar/incrustar la fuente). |
| **Atoms/Icon** | ⚠️ Aproximado | Se usan círculos/formas genéricas en vez de los glyphs reales de `BC Icons` — mismo motivo que IconButton. |
| **Molecules/CardPrimary / CardContent** | ✅ Usado | Tarjetas de servidor/usuario/grupo, con borde de color por severidad (`.bc-card-primary-color-horizontal`). |
| **Molecules/Input / InputSelect** | ✅ Usado | Campos de búsqueda y selects con el borde inferior real (`.bc-input{border-bottom:2px solid}`). |
| **Molecules/TabsGroup** | ✅ Usado | Indicador negro de 3px bajo el tab activo (`.bc-tabs-border`), no amarillo como en la v1. |
| **Molecules/Paginator** | ✅ Usado (agregado en esta auditoría) | Los 3 listados (servidores/usuarios/grupos) no tenían paginación; se agregó el patrón real prev/next + página actual. |
| **Molecules/Status** | ⚠️ Aproximado | Se usó el patrón de Badge en vez del molecule Status completo (que además lleva icono) — visualmente muy cercano, misma paleta temática real. |
| **Molecules/TagButton, Tooltip, Accordion** | ⚠️ Parcial | El panel expandible de MITRE ATT&CK sigue el patrón real de expandir/colapsar (`.bc-expansion-panel`) pero está construido a mano, no es el componente Angular real. |
| **Organism/Header** | ✅ Usado | Logo real, tabs de navegación subrayadas, y ahora el avatar del usuario autenticado. |
| **Organism/Data Table / Table** | ✅ Usado | Todas las tablas (carpetas, admins, IOE, etc.) con encabezado gris claro y zebra sutil real. |
| **Organism/Search** | ⚠️ Aproximado | Se usó el molecule Input en vez del organism Search completo (que incluye filtros avanzados expandibles) — suficiente para el caso de uso de estos mockups. |
| **Organism/Menu, Footer, BreadCrumb, Calendar, Carousel, Card Authentication, FileDownload, Input Date/File, Key Validation, Transaction Confirmation** | ➖ No aplica | Componentes de navegación/transaccionales sin equivalente funcional en un dashboard de exposición de identidades. |
| **Atoms/Checkbox, RadioButton, Slider, Switch, Stepper, Loader, PreLoader, Illustration, Logos, Pictogram, PopOver, Stroke, TransactionStatus** | ➖ No aplica | No hay formularios de selección múltiple, wizards, ni estados de carga/transacción en el alcance de estas 12 pantallas estáticas. |
| **Molecules/Accordion, Alert Toast, Card TDC, CardSelect(V2), CircleLoading, Fab Menu, Input Create/Number/Token, InputFilter/SelectV2, List Row, Menu Tabs Vertical, Modal, OffCanvas, Shortcut, Sidebar, Tracker** | ➖ No aplica | Sin caso de uso claro en las pantallas solicitadas (no hay tarjetas de crédito, notificaciones toast, ni menús laterales adicionales al Header). |

**Resumen:** de los componentes con un caso de uso real en este dashboard, **todos quedaron representados** con sus tokens/patrones reales verificados contra el CSS del banco; los únicos pendientes genuinos son los *glyphs* exactos de la fuente de iconos `BC Icons` (no descargable desde este entorno) y la implementación 1:1 del componente Angular `Status`/`Search` completos (se aproximaron con Badge/Input, visualmente equivalentes).

## De dónde salió cada valor de marca usado aquí

A diferencia de la primera versión de estos mockups (basada en el manual de
marca genérico), esta versión se generó leyendo **en vivo** el storybook y el
bundle CSS reales del banco:

- Catálogo de 71 componentes (Atoms/Molecules/Organisms) leído desde
  `caribe-showcase-qa.apps.ambientesbc.com/web/ngx/16.x.x.lts/storybook/index.json`.
- Colores, tipografía, botones, badges, tabs y radios de borde extraídos
  directamente de `library-sdb.apps.bancolombia.com/bds/9.38.7/bds.min.css`
  (el bundle real que ese mismo storybook carga) — no son valores inventados
  ni tomados del manual de marca corporativo genérico.

Esto reveló varias correcciones importantes frente al manual genérico:
- El sistema real es de **tema claro** (tarjetas y tablas blancas, texto
  negro), no oscuro — se corrigió el tema de los mockups en esta versión.
- **No existe un azul marino de acento** (`#00448d`) en el sistema real de
  componentes — los botones secundarios son blancos con borde/texto negro
  (`.bc-button-secondary`), no azules.
- El azul que sí existe (`#59cbe8`, nombrado internamente **"Caribe"**) es el
  color semántico de **info**, usado aquí para el chip de "Prototipo de
  diseño", los tags de MITRE y los acentos informativos — no para botones.
- Los tabs activos llevan un subrayado **negro** de 3px
  (`.bc-tabs-border{background-color:#2c2a29}`), no amarillo.
- Existen 4 colores de severidad reales y distintos (antes solo se usaban 3):
  Crítico `#e20201` (rojo, `.bc-badge-red`), Alto `#ff7f41` (naranja "Alba",
  `.bc-bg-danger`), Medio `#fdda24` (amarillo "Macondo", `.bc-badge-yellow`) y
  Bajo `#00c389` (verde "Andino", `.bc-badge-green`).
- Los gráficos de barras usan la paleta categórica real de datos
  (`.bc-bg-data-00` a `.bc-bg-data-08`), no colores inventados.
- El logo de Bancolombia se usa en su versión **oficial negra** (no una
  variante en blanco) porque el header ahora es blanco, igual que en el
  sistema real.

No se generó el archivo directamente dentro de Figma porque esta sesión no
tenía disponible un MCP/API de Figma — estos `.svg` son el formato que Figma
importa de forma nativa (sin plugins) preservando capas, texto editable y
colores como estilos.

## Pasos para importar (recomendado: uno por uno)

1. Abre o crea un archivo en Figma.
2. Arrastra cada `.svg` de esta carpeta directamente al lienzo (drag & drop
   desde el explorador de archivos) — Figma lo convierte automáticamente en
   un grupo de capas vectoriales + texto, en el orden numérico sugerido
   (01 → 12).
3. Alternativa: `Archivo > Insertar > Imagen o video...` y selecciona el
   `.svg` — mismo resultado, un frame por pantalla.
4. Una vez importado, selecciona el grupo resultante y usa
   `Clic derecho > Ungroup` (o `Ctrl/Cmd+Shift+G`) si quieres separar el
   encabezado, las tarjetas, los botones, etc. en capas independientes.
5. Organiza cada pantalla importada en su propio frame (`F`) y nómbralo igual
   que el archivo (ej. "01 · Dashboard principal") para mantener trazabilidad.

## Notas de fidelidad

- Tipografía: el sistema real usa **"CIB Sans Bold"** para títulos/labels y
  **"Open Sans"** para cuerpo de texto (confirmado en `body{font-family:...}`
  del bundle real) — los SVG ya declaran estas fuentes con su mismo fallback;
  si tu Figma no las tiene instaladas, se verán con la fuente por defecto del
  sistema hasta que instales/vincules las oficiales.
- El logo de Bancolombia se referencia dentro del SVG como imagen embebida
  (base64, archivo oficial negro) — si tu versión de Figma no lo renderiza,
  reemplázalo manualmente por
  `.claude/skills/bancolombia-brand-manual/references/logo-bancolombia-lockup-oficial.png`.
- Todas las pantallas incluyen, sin necesidad de hacer scroll, la etiqueta
  **"PROTOTIPO DE DISEÑO — NO OFICIAL"** — no la elimines si compartes estas
  piezas fuera del equipo de diseño (regla obligatoria de
  `bancolombia-ui-ux/references/poc-and-disclaimers.md`).

## Paleta real usada (para crear Estilos de color en Figma)

| Token | Hex | Origen real (clase .bc-*) | Uso |
|---|---|---|---|
| Negro de marca | `#2c2a29` | `.bc-bg-brand-primary-00` | Texto, logo, tabs activos, botón "background" |
| Blanco | `#ffffff` | `.bc-card-container` | Superficie de tarjetas/tablas/header |
| Fondo de página | `#f9f9fa` | sequential N-50 | Canvas de la app |
| Superficie alterna | `#f2f2f4` | sequential N-100 | Header de tabla, hover, badges neutros |
| Borde | `#d9dadd` | sequential N-200 | Bordes de inputs/tarjetas |
| Amarillo (Macondo) | `#fdda24` | `.bc-button-primary` / `.bc-badge-yellow` | CTA primario, severidad Media |
| Caribe (info) | `#59cbe8` | `.bc-bg-info` / `.bc-badge-blue` | Acentos informativos, tags MITRE |
| Andino (éxito) | `#00c389` | `.bc-bg-success` / `.bc-badge-green` | Severidad Baja |
| Alba (peligro) | `#ff7f41` | `.bc-bg-danger` | Severidad Alta |
| Rojo (crítico) | `#e20201` | `.bc-badge-red` | Severidad Crítica |
| Orquídea | `#9063cd` | `.bc-badge-purple` | Tag "Attack Scenarios" |
| Paleta de datos | `#cd3f3f #ed7620 #fdda24 #00a574 #1ea1e4 #1e4dc4 #9063cd #888` | `.bc-bg-data-00..08` | Gráficos de barras |

## Lista de pantallas

| # | Archivo | Pantalla |
|---|---|---|
| 01 | `01-dashboard-principal-servers.svg` | Dashboard principal (tab Servers): búsqueda/filtros, exportar, riesgo global, gráficos, fuentes de exposición, Magic Agent |
| 02 | `02-listado-servidores.svg` | Listado de servidores en tarjetas |
| 03 | `03-detalle-servidor-carpetas.svg` | Detalle de servidor — tab Carpetas (permisos y exposición en shares) |
| 04 | `04-detalle-servidor-admins.svg` | Detalle de servidor — tab Admins (administradores locales, filtro de anomalía) |
| 05 | `05-detalle-servidor-attack-paths.svg` | Detalle de servidor — tab Attack Paths (grafo interactivo de rutas de ataque) |
| 06 | `06-detalle-servidor-ioe.svg` | Detalle de servidor — tab IOE (indicadores de exposición) |
| 07 | `07-detalle-servidor-mitre-expandido.svg` | Detalle de servidor — panel MITRE ATT&CK expandido (técnicas + evidencias) |
| 08 | `08-listado-usuarios.svg` | Listado de usuarios en tarjetas |
| 09 | `09-detalle-usuario.svg` | Detalle de usuario (tabs IOE/Servers Admin/Servers Control/Groups/Grafo) |
| 10 | `10-listado-grupos.svg` | Listado de grupos en tarjetas |
| 11 | `11-detalle-grupo.svg` | Detalle de grupo (MITRE expandido + IOE del grupo) |
| 12 | `12-estado-vacio-modulo.svg` | Estado vacío estandarizado de un módulo ("Sin resultados.") |
